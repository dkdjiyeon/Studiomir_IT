from datetime import datetime

import pytz
from flask import Blueprint, render_template, jsonify, request
from pybo import db
from pybo.models import Schedule
from pybo.views.main_views import permission_required

bp = Blueprint("schedule", __name__, url_prefix="/schedule")


# 스케줄 리스트 페이지 렌더링
@bp.route('/list/')
@permission_required(['admin'])
def _list():
    return render_template('schedule/schedule_list.html')


@bp.route('/events')
@permission_required(['admin'])
def events():
    schedules = Schedule.query.all()
    events = []
    if schedules:
        for schedule in schedules:
            events.append({
                'id': schedule.id,
                'calendarId': schedule.calendar_id,
                'title': schedule.title,
                'category': 'time',
                'dueDateClass': '',
                'start': schedule.start_date.strftime('%Y-%m-%dT%H:%M:%S'),
                'end': schedule.end_date.strftime('%Y-%m-%dT%H:%M:%S') if schedule.end_date else None,
                'backgroundColor': schedule.background_color if schedule.background_color else '#03bd9e',
                'borderColor': schedule.border_color if schedule.border_color else '#03bd9e'
            })
    return jsonify(events)  # 빈 리스트라도 반환


@bp.route('/add/', methods=['POST'])
@permission_required(['admin'])
def add_event():
    print("Request received at /add")  # 요청 도착 확인
    data = request.get_json()
    print("Request JSON:", data)  # 요청 데이터 확인
    title = data.get('title')
    start_date_str = data.get('start')
    end_date_str = data.get('end', None)
    calendar_id = data.get('calendarId')  # 추가: calendarId 가져오기

    # 색상 정보 직접 가져오기
    background_color = data.get('backgroundColor', '#03bd9e')
    border_color = data.get('borderColor', '#03bd9e')
    # ISO 형식에서 UTC 시간대로 명시적으로 변환
    utc = pytz.UTC  # UTC 시간대
    korea_tz = pytz.timezone('Asia/Seoul')  # 한국 시간대

    # UTC 시간을 명시적으로 처리하고 한국 시간대로 변환
    start_date = datetime.fromisoformat(start_date_str.replace('Z', '')).replace(tzinfo=utc).astimezone(korea_tz)
    end_date = datetime.fromisoformat(end_date_str.replace('Z', '')).replace(tzinfo=utc).astimezone(korea_tz) if end_date_str else None

    # 변환된 시간대로 DB 저장
    new_schedule = Schedule(
        title=title,
        start_date=start_date,
        end_date=end_date,
        calendar_id=calendar_id,  # 추가: calendarId 저장
        background_color=background_color,
        border_color=border_color
    )
    db.session.add(new_schedule)
    db.session.commit()
    return jsonify({'success': True})


@bp.route('/update/<int:schedule_id>', methods=['PUT'])
@permission_required(['admin'])
def update_event(schedule_id):
    data = request.get_json()
    schedule = Schedule.query.get_or_404(schedule_id)

    # 새롭게 받은 제목, 시작, 종료 시간을 처리
    schedule.title = data.get('title', schedule.title)
    start_date_str = data.get('start')
    end_date_str = data.get('end', None)
    schedule.calendar_id = data.get('calendarId', schedule.calendar_id)  # 추가: calendarId 업데이트
    # 배경색과 테두리색을 가져오고 기본값은 기존 색상으로 설정
    schedule.background_color = data.get('backgroundColor', schedule.background_color)
    schedule.border_color = data.get('borderColor', schedule.border_color)

    korea_tz = pytz.timezone('Asia/Seoul')

    # 시작 날짜가 문자열인지 확인
    if isinstance(start_date_str, str):
        start_date = datetime.fromisoformat(start_date_str).astimezone(korea_tz)
    else:
        start_date = schedule.start_date

    # 종료 날짜가 문자열인지 확인
    if isinstance(end_date_str, str):
        end_date = datetime.fromisoformat(end_date_str).astimezone(korea_tz)
    else:
        end_date = schedule.end_date

    schedule.start_date = start_date
    schedule.end_date = end_date

    db.session.commit()  # DB에 수정된 일정 반영
    return jsonify({'success': True})


@bp.route('/delete/<int:schedule_id>', methods=['DELETE'])
@permission_required(['admin'])
def delete_event(schedule_id):
    schedule = Schedule.query.get_or_404(schedule_id)
    db.session.delete(schedule)
    db.session.commit()
    return jsonify({'success': True})


@bp.route('/add-schedule', methods=['POST'])
@permission_required(['admin'])
def add_schedule():
    data = request.get_json()
    title = data.get('title')
    start_date = datetime.datetime.fromisoformat(data.get('start_date'))

    new_schedule = Schedule(title=title, start_date=start_date)
    db.session.add(new_schedule)
    db.session.commit()
    return jsonify({'status': 'success', 'message': 'Schedule added'})