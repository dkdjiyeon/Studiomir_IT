from flask import Blueprint, render_template
from pybo.views.main_views import permission_required

bp = Blueprint("schedule", __name__, url_prefix="/schedule")


# 스케줄 리스트 페이지 렌더링
@bp.route('/list')
@permission_required(['admin'])
def _list():
    return render_template('schedule/schedule_list.html')
