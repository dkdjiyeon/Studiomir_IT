import click
from flask.cli import with_appcontext

from . import db
from .models import Worker, Headquarter, Department, BuyProductRenew, EquipmentList


@click.command("seed-data")
@with_appcontext
def seed_data():
    """초기 데이터를 데이터베이스에 삽입"""
    if not Headquarter.query.filter_by(id=1).first():
        initial_data = Headquarter(id=1, name="None")
        db.session.add(initial_data)
        db.session.commit()

    if not Department.query.filter_by(id=1).first():
        initial_data = Department(id=1, name="None")
        db.session.add(initial_data)
        db.session.commit()

    if not Worker.query.filter_by(id=1).first():
        initial_data = Worker(id=1, name="None", nickname="None", email="None", headquarter="None", department="None")
        db.session.add(initial_data)
        db.session.commit()

    if not BuyProductRenew.query.filter_by(id=1).first():
        initial_data = [
            BuyProductRenew(id=1, renew="라이센스(갱신)"),
            BuyProductRenew(id=2, renew="라이센스(영구)")

        ]
        db.session.bulk_save_objects(initial_data)
        db.session.commit()
