import os
from datetime import datetime

import qrcode
from flask import Blueprint, render_template, request, url_for, current_app
from werkzeug.utils import redirect

from pybo import db
from pybo.forms import ProductForm, ItemForm
from pybo.models import Equipment, EquipmentList, EquipmentHistory, Worker, Department, Ip, Headquarter, SSD
from pybo.views.main_views import permission_required

bp = Blueprint("equipment", __name__, url_prefix="/equipment")


@bp.route("/list/")
@permission_required(['admin'])
def _list():
    item_list = EquipmentList.query.order_by(EquipmentList.id.asc())
    department_list = Department.query.order_by(Department.name.asc())
    detail_list = {item.name: Equipment.query.filter_by(kind=item.name).order_by(Equipment.serial.desc()).all()
                   for item in item_list}
    item_count = {item.name: Equipment.query.filter_by(kind=item.name).count()
                  for item in item_list}
    enroll_count = {item.name: Equipment.query.filter(Equipment.kind == item.name, Equipment.person != "None").count()
                    for item in item_list}

    return render_template('equipment/equipment_list.html', item_list=item_list, detail_list=detail_list,
                           item_count=item_count, enroll_count=enroll_count, department_list=department_list)


@bp.route('/sort/', methods=['GET'])
@permission_required(['admin'])
def sort():
    item_list = EquipmentList.query.order_by(EquipmentList.id.asc())
    department_list = Department.query.order_by(Department.name.asc())
    sort_column = request.args.get('sort_column', 'serial')

    # 허용된 정렬 컬럼 체크
    allowed_columns = ['serial', 'person', 'department']
    if sort_column not in allowed_columns:
        sort_column = 'serial'  # 기본값

    # 각 탭에 해당하는 데이터를 가져오기
    detail_list = {item.name: Equipment.query.filter_by(kind=item.name).order_by(sort_column).all()
                   for item in item_list}
    item_count = {item.name: Equipment.query.filter_by(kind=item.name).count()
                  for item in item_list}
    enroll_count = {item.name: Equipment.query.filter(Equipment.kind == item.name, Equipment.person != "None").count()
                    for item in item_list}

    return render_template('equipment/equipment_list.html', item_list=item_list, detail_list=detail_list,
                           item_count=item_count, enroll_count=enroll_count, department_list=department_list)


@bp.route('/dp_sort/', methods=['GET'])
@permission_required(['admin'])
def dp_sort():
    item_list = EquipmentList.query.order_by(EquipmentList.id.asc())
    department_list = Department.query.order_by(Department.name.asc())
    department_filter = request.args.get('department_filter')

    if department_filter == "None":
        detail_list = {item.name: Equipment.query.filter_by(department=department_filter).all()
                       for item in item_list}
    else:
        detail_list = {item.name: Equipment.query.filter(Equipment.kind == item.name,
                                                         Equipment.department == department_filter).all()
                       for item in item_list}
    item_count = {item.name: Equipment.query.filter_by(kind=item.name).count()
                  for item in item_list}
    enroll_count = {item.name: Equipment.query.filter(Equipment.kind == item.name, Equipment.person != "None").count()
                    for item in item_list}

    return render_template('equipment/equipment_list.html', item_list=item_list, detail_list=detail_list,
                           item_count=item_count, enroll_count=enroll_count, department_list=department_list)


@bp.route("/enroll/")
@permission_required(['admin'])
def enroll():
    form = ProductForm()
    item_list = EquipmentList.query.order_by(EquipmentList.id.asc())
    item_list_serialized = [{"name": item.name, "title": item.title} for item in item_list]
    item_list = EquipmentList.query.order_by(EquipmentList.id.asc()).all()
    item_count = {item.name: Equipment.query.filter_by(kind=item.name).count() for item in item_list}
    department_list = Department.query.order_by(Department.name.asc())
    headquarter_list = Headquarter.query.order_by(Headquarter.name.asc())
    worker_list = Worker.query.filter(Worker.resign.is_(None)).order_by(Worker.name.asc()).all()
    ip_list = Ip.query.filter(Ip.person.is_(None)).all()

    return render_template("equipment/equipment_enroll.html", item_list=item_list, form=form,
                           worker_list=worker_list, item_list_serialized=item_list_serialized,
                           item_count_serialized=item_count,
                           department_list=department_list, headquarter_list=headquarter_list, ip_list=ip_list)


@bp.route("/enroll_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def enroll_complete():
    form = ProductForm()
    item_list = EquipmentList.query.order_by(EquipmentList.id.asc())
    department_list = Department.query.order_by(Department.name.asc())
    headquarter_list = Headquarter.query.order_by(Headquarter.name.asc())
    worker_list = Worker.query.filter(Worker.resign.is_(None)).order_by(Worker.name.asc()).all()
    ip_list = Ip.query.filter(Ip.person == "None").all()
    equipment_number = Equipment.query.filter(Equipment.serial == form.serial.data).first()

    if request.method == "POST" and form.validate_on_submit():
        if equipment_number:
            return "이미 등록된 장비번호입니다.", 404

        cpu_price_int = form.cpu_price.data.replace(",", "")
        mainboard_price_int = form.mainboard_price.data.replace(",", "")
        graphiccard_price_int = form.graphiccard_price.data.replace(",", "")
        memory_price_int = form.memory_price.data.replace(",", "")
        memory_count_int = form.memory_count.data.replace(",", "")
        memory_sum_int = form.memory_sum.data.replace(",", "")
        subtotal_int = form.subtotal.data.replace(",", "")
        subtotal2_int = form.subtotal2.data.replace(",", "")
        vat_int = form.vat.data.replace(",", "")
        total_int = form.total.data.replace(",", "")
        ssd_list = request.form.getlist('ssd[]')  # 배열 형태로 수집
        ssd_price_list = request.form.getlist('ssd_price[]')

        values = [cpu_price_int, mainboard_price_int, graphiccard_price_int, memory_price_int, memory_count_int,
                  memory_sum_int, subtotal_int, subtotal2_int, vat_int, total_int]

        for value in values:
            if not value.isdigit():
                return "금액은 숫자로만 입력하세요.", 404

        for ssd_p in ssd_price_list:
            ssd_p_int = ssd_p.replace(",", "")
            if not ssd_p_int.isdigit():
                return "금액은 숫자로만 입력하세요.", 404

        for worker in worker_list:
            if worker.nickname == form.nickname.data:
                person_name = worker.name
                break
        equipment = Equipment(
            kind=form.kind.data.strip(),
            serial=form.serial.data,
            ip_add=form.ip_add.data,
            person=person_name,
            nickname=form.nickname.data,
            headquarter=form.headquarter.data,
            department=form.department.data,
            buy_date=form.buy_date.data,
            cpu=form.cpu.data,
            cpu_price=form.cpu_price.data,
            mainboard=form.mainboard.data,
            mainboard_price=form.mainboard_price.data,
            graphiccard=form.graphiccard.data,
            graphiccard_price=form.graphiccard_price.data,
            memory=form.memory.data,
            memory_price=form.memory_price.data,
            memory_count=form.memory_count.data,
            memory_sum=form.memory_sum.data,
            vat=form.vat.data,
            subtotal=form.subtotal.data,
            subtotal2=form.subtotal2.data,
            total=form.total.data,
            equip_num=form.equip_num.data,
            note=form.note.data,
        )

        db.session.add(equipment)
        db.session.commit()

        # QR 코드 생성
        qr_url = f"{current_app.config['BASE_URL']}/equipment/revise/{equipment.id}"
        qr_data = f"장비ID: {equipment.id}\n장비번호: {form.serial.data}\nURL: {qr_url}"
        qr = qrcode.make(qr_data)

        # 이미지 저장 경로 설정
        qr_folder = os.path.join(current_app.root_path, 'static', 'qr_codes')
        qr_filename = f"qr_{equipment.id}.png"
        qr_path = os.path.join(qr_folder, qr_filename)
        qr.save(qr_path)

        # 웹에서 접근 가능한 경로를 데이터베이스에 저장
        qr_web_path = f"/static/qr_codes/{qr_filename}"
        equipment.qr_code_path = qr_web_path

        equipment_history = EquipmentHistory(
            kind=form.kind.data.strip(),
            serial=form.serial.data,
            ip_add=form.ip_add.data,
            person=person_name,
            nickname=form.nickname.data,
            headquarter=form.headquarter.data,
            department=form.department.data,
            buy_date=form.buy_date.data,
            cpu=form.cpu.data,
            mainboard=form.mainboard.data,
            graphiccard=form.graphiccard.data,
            memory=form.memory.data,
            vat=form.vat.data,
            subtotal=form.subtotal.data,
            subtotal2=form.subtotal2.data,
            total=form.total.data,
            equip_num=form.equip_num.data,
            note=form.note.data,
            equipment_id=equipment.id,
            modify_date=datetime.now(),
        )

        db.session.add(equipment_history)
        db.session.commit()

        for ssd, price in zip(ssd_list, ssd_price_list):
            if ssd.strip() and price.strip():
                new_ssd = SSD(
                    name=ssd,
                    price=price,
                    equipment_id=equipment.id,
                    history_id=equipment_history.id
                )
                db.session.add(new_ssd)
        db.session.commit()
        return redirect(url_for("equipment._list"))

    return render_template("equipment/equipment_enroll.html", item_list=item_list, form=form,
                           worker_list=worker_list,
                           department_list=department_list, headquarter_list=headquarter_list, ip_list=ip_list)


@bp.route("/print_all/")
@permission_required(['admin'])
def print_all():
    equipment = Equipment.query.order_by(Equipment.person).all()

    for eq in equipment:
        # QR 코드 생성
        qr_url = f"{current_app.config['BASE_URL']}/equipment/revise/{eq.id}"
        qr_data = f"장비ID: {eq.id}\n장비번호: {eq.serial}\nURL: {qr_url}"
        qr = qrcode.make(qr_data)

        # 이미지 저장 경로 설정
        qr_folder = os.path.join(current_app.root_path, 'static', 'qr_codes')
        os.makedirs(qr_folder, exist_ok=True)
        qr_filename = f"qr_{eq.id}.png"
        qr_path = os.path.join(qr_folder, qr_filename)
        qr.save(qr_path)

        # 웹에서 접근 가능한 경로를 데이터베이스에 저장
        qr_web_path = f"/static/qr_codes/{qr_filename}"
        eq.qr_code_path = qr_web_path
        db.session.commit()

    return render_template("equipment/equipment_print_all.html", equipment=equipment)


@bp.route("/print_qr/<int:equipment_id>/")
@permission_required(['admin'])
def print_qr(equipment_id):
    eq = Equipment.query.get_or_404(equipment_id)

    # QR 코드 생성
    qr_url = f"{current_app.config['BASE_URL']}/equipment/revise/{eq.id}"
    qr_data = f"장비ID: {eq.id}\n장비번호: {eq.serial}\nURL: {qr_url}"
    qr = qrcode.make(qr_data)

    # 이미지 저장 경로 설정
    qr_folder = os.path.join(current_app.root_path, 'static', 'qr_codes')
    os.makedirs(qr_folder, exist_ok=True)
    qr_filename = f"qr_{eq.id}.png"
    qr_path = os.path.join(qr_folder, qr_filename)
    qr.save(qr_path)

    # 웹에서 접근 가능한 경로
    qr_web_path = f"/static/qr_codes/{qr_filename}"
    eq.qr_code_path = qr_web_path
    db.session.commit()

    return render_template("equipment/equipment_print_all.html", equipment=[eq], qr_path=qr_web_path)


@bp.route("/revise/<int:product_id>/")
@permission_required(['admin'])
def revise(product_id):
    if product_id == 0:
        return "장비배정이 되지 않았습니다", 404
    form = ProductForm()
    item_list = EquipmentList.query.order_by(EquipmentList.id.asc())
    equipment = Equipment.query.get_or_404(product_id)
    worker_list = Worker.query.filter(Worker.resign.is_(None)).order_by(Worker.name.asc()).all()
    selected_ip = Equipment.query.filter_by(id=product_id).first()
    ip_list = Ip.query.filter(Ip.person.is_(None)).all()
    if selected_ip.ip_add is not None and selected_ip.ip_add != "None":
        ip_list += [selected_ip]

    ssd_data = SSD.query.filter_by(equipment_id=product_id).all()

    return render_template("equipment/equipment_revise.html", item_list=item_list, form=form, equipment=equipment,
                           worker_list=worker_list, ip_list=ip_list, ssd_data=ssd_data, selected_ip=selected_ip)


@bp.route("/revise_complete/<int:product_id>/", methods=["GET", "POST"])
@permission_required(['admin'])
def revise_complete(product_id):
    form = ProductForm()
    item_list = EquipmentList.query.order_by(EquipmentList.id.asc())
    equipment = Equipment.query.get_or_404(product_id)
    worker_list = Worker.query.filter(Worker.resign.is_(None)).order_by(Worker.name.asc()).all()
    ip_list = Ip.query.order_by(Ip.id.asc())
    ssds = SSD.query.filter_by(equipment_id=product_id).all()

    if request.method == "POST" and form.validate_on_submit():
        cpu_price_int = form.cpu_price.data.replace(",", "")
        mainboard_price_int = form.mainboard_price.data.replace(",", "")
        graphiccard_price_int = form.graphiccard_price.data.replace(",", "")
        memory_price_int = form.memory_price.data.replace(",", "")
        memory_count_int = form.memory_count.data.replace(",", "")
        memory_sum_int = form.memory_sum.data.replace(",", "")
        subtotal_int = form.subtotal.data.replace(",", "")
        subtotal2_int = form.subtotal2.data.replace(",", "")
        vat_int = form.vat.data.replace(",", "")
        total_int = form.total.data.replace(",", "")
        ssd_list = request.form.getlist('ssd[]')  # 배열 형태로 수집
        ssd_price_list = request.form.getlist('ssd_price[]')

        values = [cpu_price_int, mainboard_price_int, graphiccard_price_int, memory_price_int, memory_count_int,
                  memory_sum_int, subtotal_int, subtotal2_int, vat_int, total_int]

        for value in values:
            if not value.isdigit():
                return "금액은 숫자로만 입력하세요.", 404

        for ssd_p in ssd_price_list:
            ssd_p_int = ssd_p.replace(",", "")
            if not ssd_p_int.isdigit():
                return "금액은 숫자로만 입력하세요.", 404

        for worker in worker_list:
            if worker.nickname == form.nickname.data:
                person_name = worker.name
                break
        # 기존 Equipment 객체의 필드 업데이트
        equipment.kind = form.kind.data.strip()
        equipment.serial = form.serial.data
        equipment.ip_add = form.ip_add.data
        equipment.person = person_name
        equipment.nickname = form.nickname.data
        equipment.headquarter = form.headquarter.data
        equipment.department = form.department.data
        equipment.buy_date = form.buy_date.data
        equipment.cpu = form.cpu.data
        equipment.cpu_price = form.cpu_price.data
        equipment.mainboard = form.mainboard.data
        equipment.mainboard_price = form.mainboard_price.data
        equipment.graphiccard = form.graphiccard.data
        equipment.graphiccard_price = form.graphiccard_price.data
        equipment.memory = form.memory.data
        equipment.memory_price = form.memory_price.data
        equipment.memory_count = form.memory_count.data
        equipment.memory_sum = form.memory_sum.data
        equipment.vat = form.vat.data
        equipment.subtotal = form.subtotal.data
        equipment.subtotal2 = form.subtotal2.data
        equipment.total = form.total.data
        equipment.equip_num = form.equip_num.data
        equipment.note = form.note.data

        equipment_history = EquipmentHistory(
            kind=form.kind.data.strip(),
            serial=form.serial.data,
            ip_add=form.ip_add.data,
            person=person_name,
            nickname=form.nickname.data,
            headquarter=form.headquarter.data,
            department=form.department.data,
            buy_date=form.buy_date.data,
            cpu=form.cpu.data,
            mainboard=form.mainboard.data,
            graphiccard=form.graphiccard.data,
            memory=form.memory.data,
            subtotal=form.subtotal.data,
            subtotal2=form.subtotal2.data,
            total=form.total.data,
            equip_num=form.equip_num.data,
            note=form.note.data,
            equipment_id=equipment.id,
            modify_date=datetime.now(),

        )

        db.session.add(equipment_history)
        db.session.commit()

        # 기존 ssd/hard 삭제
        for s in ssds:
            db.session.delete(s)
        db.session.commit()

        for ssd, price in zip(ssd_list, ssd_price_list):
            if ssd.strip() and price.strip():
                new_ssd = SSD(
                    name=ssd,
                    price=price,
                    equipment_id=equipment.id,
                    history_id=equipment_history.id  # EquipmentHistory와 연결
                )
                db.session.add(new_ssd)
        db.session.commit()
        return redirect(url_for("equipment._list", name=form.person.data))
    return render_template("equipment/equipment_revise.html", item_list=item_list, form=form, equipment=equipment,
                           worker_list=worker_list, ip_list=ip_list)


@bp.route("/add/")
@permission_required(['admin'])
def add():
    form = ItemForm()
    return render_template("equipment/equipment_add.html", form=form)


@bp.route("/add_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def add_complete():
    itemform = ItemForm()
    name = request.form['action']
    if request.method == "POST" and itemform.validate_on_submit():
        if name == "추가":
            equipment_list = EquipmentList(name=itemform.name.data, title=itemform.title.data)
            db.session.add(equipment_list)
            db.session.commit()
            return redirect(url_for("equipment._list"))
        elif name == "삭제":
            if itemform.name.data == "컴퓨터":
                return "기본항목이므로 삭제할 수 없습니다", 404
            equipment_list = EquipmentList.query.filter_by(name=itemform.name.data).first()
            if equipment_list:
                db.session.delete(equipment_list)
                db.session.commit()
                return redirect(url_for("equipment._list"))
            else:
                # 삭제할 항목이 없는 경우 처리
                return "삭제할 항목이 없습니다.", 404
    return render_template("equipment/equipment_add.html", form=itemform)


@bp.route("/detail/<int:product_id>/")
@permission_required(['admin'])
def detail(product_id):
    equipment = Equipment.query.get_or_404(product_id)
    ssd_list = SSD.query.filter_by(equipment_id=product_id).all()
    total_price = sum(int(ssd.price.replace(",", "")) for ssd in ssd_list)

    return render_template("equipment/equipment_detail.html", equipment=equipment, ssd_list=ssd_list,
                           total_price=total_price)


@bp.route("/history/<int:product_id>/")
@permission_required(['admin'])
def history(product_id):
    item_list = EquipmentHistory.query.filter_by(equipment_id=product_id).order_by(
        EquipmentHistory.modify_date.desc()).all()
    ssd_list = SSD.query.filter_by(equipment_id=product_id).all()
    return render_template("equipment/equipment_history.html", item_list=item_list, ssd_list=ssd_list)


@bp.route("/delete/<int:product_id>/")
@permission_required(['admin'])
def delete(product_id):
    item = Equipment.query.filter_by(id=product_id).first()
    ip = Ip.query.filter_by(equipment_id=product_id).first()
    if ip:
        ip.person = None
        ip.nickname = None
        ip.headquarter = None
        ip.department = None
        ip.serial = None
        ip.equipment_id = None
        ip.note = None

    db.session.delete(item)
    db.session.commit()
    return render_template("equipment/equipment_delete.html", item=item)
