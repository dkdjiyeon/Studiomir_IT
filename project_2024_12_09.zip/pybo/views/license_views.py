from pybo.models import UpperTab, LowerTab, License, LicenseHistory, Worker, BuyProduct
from pybo.forms import LicenseForm, TabForm, TabListForm, ItemForm, RenewChangeForm
from flask import Blueprint, render_template, request, url_for
from werkzeug.utils import redirect
from pybo import db
from pybo.views.main_views import permission_required
from datetime import datetime

bp = Blueprint("license", __name__, url_prefix="/license")


@bp.route("/list/")
@permission_required(['admin'])
def _list():
    form = ItemForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.id.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.id.asc())

    buy_count = {}
    enroll_count = {}
    not_enroll_count = {}
    reference_date = datetime.now()

    # 하위탭별 라이센스 필터링 데이터 준비
    filtered_license_list = {}
    for lower_tab in lower_tab_list:
        filtered_license_list[lower_tab.name] = License.query.filter(License.sub_kind == lower_tab.name).order_by(
            License.product_name.asc()).all()

        # 각 하위탭의 개수 계산
        lower_tab_enroll_count = 0
        lower_tab_not_enroll_count = 0
        for l in filtered_license_list[lower_tab.name]:
            if l.person != "None" and l.renew == "갱신":
                lower_tab_enroll_count += 1
            elif l.person != "None" and l.renew == "영구":
                lower_tab_enroll_count += 1
            elif l.person != "None" and l.renew == "비정품":
                lower_tab_not_enroll_count += 1

        enroll_count[lower_tab.name] = lower_tab_enroll_count
        not_enroll_count[lower_tab.name] = lower_tab_not_enroll_count

        buy_product = BuyProduct.query.filter(BuyProduct.product_name == lower_tab.name).all()

        # `buy_count` 딕셔너리에 키가 없으면 초기화
        if lower_tab.name not in buy_count:
            buy_count[lower_tab.name] = 0

        for product in buy_product:
            if product.renew == "라이센스(갱신)" and product.expire_date >= reference_date:
                buy_count[lower_tab.name] += product.amount
            elif product.renew == "라이센스(영구)":
                buy_count[lower_tab.name] += product.amount

    return render_template("license/license_list.html", upper_tab_list=upper_tab_list, lower_tab_list=lower_tab_list,
                           enroll_count=enroll_count, not_enroll_count=not_enroll_count,
                           filtered_license_list=filtered_license_list,
                           buy_count=buy_count, form=form)


@bp.route('/sort/', methods=['GET'])
@permission_required(['admin'])
def sort():
    form = ItemForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.id.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.id.asc())
    buy_count = {}
    enroll_count = {}
    not_enroll_count = {}
    reference_date = datetime.now()
    item_list = LowerTab.query.order_by(LowerTab.id.asc())
    sort_column = request.args.get('sort_column', 'serial')

    # 허용된 정렬 컬럼 체크
    allowed_columns = ['person', 'department', 'renew']
    if sort_column not in allowed_columns:
        sort_column = 'product_name'  # 기본값

    # 하위탭별 라이센스 필터링 데이터 준비
    filtered_license_list = {}
    for lower_tab in lower_tab_list:
        filtered_license_list[lower_tab.name] = License.query.filter(License.sub_kind == lower_tab.name).order_by(
            sort_column).all()

        # 각 하위탭의 개수 계산
        lower_tab_enroll_count = 0
        lower_tab_not_enroll_count = 0
        for l in filtered_license_list[lower_tab.name]:
            if l.person != "None" and l.renew == "갱신":
                lower_tab_enroll_count += 1
            elif l.person != "None" and l.renew == "영구":
                lower_tab_enroll_count += 1
            elif l.person != "None" and l.renew == "비정품":
                lower_tab_not_enroll_count += 1

        enroll_count[lower_tab.name] = lower_tab_enroll_count
        not_enroll_count[lower_tab.name] = lower_tab_not_enroll_count

        buy_product = BuyProduct.query.filter(BuyProduct.product_name == lower_tab.name).all()

        # `buy_count` 딕셔너리에 키가 없으면 초기화
        if lower_tab.name not in buy_count:
            buy_count[lower_tab.name] = 0

        for product in buy_product:
            if product.renew == "라이센스(갱신)" and product.expire_date >= reference_date:
                buy_count[lower_tab.name] += product.amount
            elif product.renew == "라이센스(영구)":
                buy_count[lower_tab.name] += product.amount

    return render_template('license/license_list.html', upper_tab_list=upper_tab_list,
                           lower_tab_list=lower_tab_list,
                           enroll_count=enroll_count, not_enroll_count=not_enroll_count,
                           filtered_license_list=filtered_license_list,
                           buy_count=buy_count, form=form)


@bp.route("/enroll/")
@permission_required(['admin'])
def enroll():
    form = LicenseForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.name.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    worker_list = Worker.query.order_by(Worker.name.asc())
    return render_template("license/license_enroll.html", form=form, worker_list=worker_list,
                           upper_tab_list=upper_tab_list,
                           lower_tab_list=lower_tab_list)


@bp.route("/enroll_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def enroll_complete():
    form = LicenseForm()
    lower_tab_list = LowerTab.query.order_by(LowerTab.id.asc())
    worker_list = Worker.query.order_by(Worker.name.asc())
    reference_date = datetime.now()

    if request.method == "POST" and form.validate_on_submit():
        for worker in worker_list:
            if worker.nickname == form.nickname.data:
                person_name = worker.name
                break

        # 라이센스 관련 계산
        license_use_count = {}
        for lower_tab in lower_tab_list:
            legal_use = License.query.filter(License.sub_kind == lower_tab.name, License.person != "None",
                                             License.renew != "비정품").count()
            license_use_count[lower_tab.name] = {"legal_use": legal_use}

            buy_product = BuyProduct.query.filter(BuyProduct.product_name == lower_tab.name).all()
            license_use_count[lower_tab.name]["buy_count"] = 0
            for product in buy_product:
                if product.renew == "라이센스(갱신)" and product.expire_date >= reference_date:
                    license_use_count[lower_tab.name]["buy_count"] += product.amount
                elif product.renew == "라이센스(영구)":
                    license_use_count[lower_tab.name]["buy_count"] += product.amount

        if form.renew.data == "비정품" or license_use_count[form.sub_kind.data.strip()]["legal_use"] < \
                license_use_count[form.sub_kind.data.strip()][
                    "buy_count"]:
            license = License(
                kind=form.kind.data.strip(),
                sub_kind=form.sub_kind.data.strip(),
                product_name=form.product_name.data,
                person=person_name,
                nickname=form.nickname.data,
                headquarter=form.headquarter.data,
                department=form.department.data,
                renew=form.renew.data,
                note=form.note.data,
            )

            db.session.add(license)
            db.session.commit()
            license_history = LicenseHistory(
                kind=form.kind.data.strip(),
                sub_kind=form.sub_kind.data.strip(),
                product_name=form.product_name.data,
                person=person_name,
                nickname=form.nickname.data,
                headquarter=form.headquarter.data,
                department=form.department.data,
                renew=form.renew.data,
                note=form.note.data,
                license_id=license.id,
                modify_date=datetime.now(),
            )

            db.session.add(license_history)
            db.session.commit()
            return redirect(url_for("license._list"))
        else:
            return "구매수량을 초과할 수 없습니다", 404
    return render_template("license/license_enroll.html", lower_tab_list=lower_tab_list, form=form,
                           worker_list=worker_list)


@bp.route("/revise/<int:product_id>/")
@permission_required(['admin'])
def revise(product_id):
    form = LicenseForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.name.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    item_list = License.query.order_by(License.id.asc())
    worker_list = Worker.query.order_by(Worker.name.asc())
    license = License.query.get_or_404(product_id)

    return render_template("license/license_revise.html", item_list=item_list, form=form, license=license,
                           worker_list=worker_list, upper_tab_list=upper_tab_list, lower_tab_list=lower_tab_list)


@bp.route("/revise_complete/<int:product_id>/", methods=["GET", "POST"])
@permission_required(['admin'])
def revise_complete(product_id):
    form = LicenseForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.name.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    license = License.query.get_or_404(product_id)
    worker_list = Worker.query.order_by(Worker.name.asc())

    if request.method == "POST" and form.validate_on_submit():
        for worker in worker_list:
            if worker.nickname == form.nickname.data:
                person_name = worker.name
                break

        # 기존 License 객체의 필드 업데이트
        license.kind = form.kind.data.strip()
        license.sub_kind = form.sub_kind.data.strip()
        license.product_name = form.product_name.data
        license.person = person_name
        license.nickname = form.nickname.data
        license.headquarter = form.headquarter.data
        license.department = form.department.data
        license.renew = form.renew.data
        license.note = form.note.data

        license_history = LicenseHistory(
            kind=form.kind.data.strip(),
            sub_kind=form.sub_kind.data.strip(),
            product_name=form.product_name.data,
            person=person_name,
            nickname=form.nickname.data,
            headquarter=form.headquarter.data,
            department=form.department.data,
            renew=form.renew.data,
            note=form.note.data,
            license_id=license.id,
            modify_date=datetime.now(),
        )

        db.session.add(license_history)
        db.session.commit()
        return redirect(url_for("license._list", name=form.person.data))
    return render_template("license/license_revise.html", form=form, license=license, upper_tab_list=upper_tab_list,
                           lower_tab_list=lower_tab_list)


@bp.route("/add/")
@permission_required(['admin'])
def add():
    form = TabForm()
    return render_template("license/license_add.html", form=form)


@bp.route("/add_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def add_complete():
    form = TabForm()
    if request.method == "POST" and form.validate_on_submit():
        new_upper_tab_name = form.upper_tab.data.strip()
        upper_tab = UpperTab.query.filter_by(name=new_upper_tab_name).first()

        # 상위탭이 없으면 새로 생성하고 DB에 추가합니다.
        if not upper_tab:
            upper_tab = UpperTab(name=new_upper_tab_name)
            db.session.add(upper_tab)
            db.session.commit()  # 먼저 commit하여 id가 생성되도록 합니다.

        # 하위탭을 상위탭에 연결하여 생성하고 추가합니다.
        new_lower_tab_name = form.lower_tab.data.strip()
        lower_tab = LowerTab(name=new_lower_tab_name, upper_tab=upper_tab)
        db.session.add(lower_tab)
        db.session.commit()
        return redirect(url_for("license._list"))

    return render_template("license/license_add.html", form=form)


@bp.route("/renew_update/", methods=["POST"])
@permission_required(['admin'])
def renew_update():
    new_renew_type = request.form.get("renew_change")
    selected_items = request.form.getlist("selectedItems")

    if not new_renew_type:
        return "갱신 여부를 선택해 주세요", 404
    if not selected_items:
        return "하나 이상의 항목을 선택해 주세요", 404

    # 선택된 ID 항목만 갱신 상태 업데이트
    License.query.filter(License.id.in_(selected_items)).update(
        {"renew": new_renew_type}, synchronize_session=False
    )
    db.session.commit()

    return redirect(url_for("license._list"))



@bp.route("/list_delete/")
@permission_required(['admin'])
def list_delete():
    form = TabListForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.name.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    return render_template("license/license_list_delete.html", form=form, upper_tab_list=upper_tab_list,
                           lower_tab_list=lower_tab_list)


@bp.route("/list_delete_complete/", methods=['POST'])
@permission_required(['admin'])
def list_delete_complete():
    form = TabListForm()
    if request.form['action'] == '대분류 삭제':
        upper_tab_name = request.form.get('upper_tab', '').strip()
        upper_tab = UpperTab.query.filter_by(name=upper_tab_name).first()
        if upper_tab:
            db.session.delete(upper_tab)
            db.session.commit()
        else:
            return "삭제할 항목이 없습니다.", 404
        return redirect(url_for("license._list"))

    elif request.form['action'] == '중분류 삭제':
        lower_tab_name = request.form.get('lower_tab', '').strip()
        lower_tab = LowerTab.query.filter_by(name=lower_tab_name).first()
        if lower_tab:
            db.session.delete(lower_tab)
            db.session.commit()
        else:
            return "삭제할 항목이 없습니다.", 404
        return redirect(url_for("license._list"))
    return render_template("license/license_list_delete.html", form=form)


@bp.route("/history/<int:product_id>/")
@permission_required(['admin'])
def history(product_id):
    item_list = LicenseHistory.query.filter_by(license_id=product_id).order_by(
        LicenseHistory.modify_date.desc()).all()
    return render_template("license/license_history.html", item_list=item_list)


@bp.route("/delete/<int:product_id>/")
@permission_required(['admin'])
def delete(product_id):
    item = License.query.filter_by(id=product_id).first()
    db.session.delete(item)
    db.session.commit()
    return render_template("license/license_delete.html", item=item)
