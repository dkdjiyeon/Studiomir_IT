import os
from datetime import timedelta


# class DevelopmentConfig:
BASE_DIR = os.path.dirname(__file__)
# 기타 개발 설정들
SQLALCHEMY_DATABASE_URI = "sqlite:///{}".format(os.path.join(BASE_DIR, "pybo.db"))
SQLALCHEMY_TRACK_MODIFICATIONS = False
SECRET_KEY = "studiomir"

# 자동 로그아웃 시간 설정
PERMANENT_SESSION_LIFETIME = timedelta(minutes=30)