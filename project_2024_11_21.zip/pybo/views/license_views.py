from pybo.models import UpperTab, LowerTab, License, LicenseHistory, Worker
from pybo.forms import LicenseForm, TabForm, TabListForm, UpdateExpireDateForm
from flask import Blueprint, render_template, request, url_for, flash
from werkzeug.utils import redirect
from pybo import db
from pybo.views.main_views import permission_required
from datetime import datetime, timedelta

bp = Blueprint("license", __name__, url_prefix="/license")


@bp.route("/list/")
@permission_required(['admin'])
def _list():
    form = UpdateExpireDateForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.id.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.id.asc())
    item_count = {}
    enroll_count = {}
    expire_count = {}
    reference_date = datetime.now()

    # 하위탭별 라이센스 필터링 데이터 준비
    filtered_license_list = {}
    for lower_tab in lower_tab_list:
        filtered_license_list[lower_tab.name] = License.query.filter(License.sub_kind == lower_tab.name).order_by(
            License.product_name.asc()).all()

        # 각 하위탭의 개수, 미지정 개수, 만료 개수 계산
        lower_tab_count = len(filtered_license_list[lower_tab.name])
        item_count[lower_tab.name] = lower_tab_count
        lower_tab_enroll_count = len([l for l in filtered_license_list[lower_tab.name] if l.person != "None"])
        enroll_count[lower_tab.name] = lower_tab_enroll_count
        lower_tab_expire_count = len([l for l in filtered_license_list[lower_tab.name] if
                                      l.one_month_before and l.one_month_before < reference_date])
        expire_count[lower_tab.name] = lower_tab_expire_count
    return render_template("license/license_list.html", upper_tab_list=upper_tab_list, lower_tab_list=lower_tab_list,
                           item_count=item_count, enroll_count=enroll_count, expire_count=expire_count,
                           reference_date=reference_date, filtered_license_list=filtered_license_list, form=form)


@bp.route("/enroll/")
@permission_required(['admin'])
def enroll():
    form = LicenseForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.name.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    worker_list = Worker.query.order_by(Worker.name.asc())
    return render_template("license/license_enroll.html", form=form, worker_list=worker_list,
                           upper_tab_list=upper_tab_list,
                           lower_tab_list=lower_tab_list)


@bp.route("/enroll_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def enroll_complete():
    form = LicenseForm()
    lower_tab_list = LowerTab.query.order_by(LowerTab.id.asc())
    worker_list = Worker.query.order_by(Worker.name.asc())

    if request.method == "POST" and form.validate_on_submit():
        for worker in worker_list:
            if worker.nickname == form.nickname.data:
                person_name = worker.name
                break

        expire_date = form.expire_date.data if form.expire_date.data else None
        one_month_before = (
            expire_date - timedelta(days=30) if expire_date else None  # 연산 조건 추가
        )

        license = License(
            kind=form.kind.data.strip(),
            sub_kind=form.sub_kind.data.strip(),
            product_name=form.product_name.data,
            person=person_name,
            nickname=form.nickname.data,
            headquarter=form.headquarter.data,
            department=form.department.data,
            buy_date=form.buy_date.data,
            price=form.price.data,
            renew=form.renew.data,
            expire_date=expire_date,
            one_month_before=one_month_before,  # 처리된 값 사용
            note=form.note.data,
        )

        db.session.add(license)
        db.session.commit()
        license_history = LicenseHistory(
            kind=form.kind.data.strip(),
            sub_kind=form.sub_kind.data.strip(),
            product_name=form.product_name.data,
            person=person_name,
            nickname=form.nickname.data,
            headquarter=form.headquarter.data,
            department=form.department.data,
            buy_date=form.buy_date.data,
            price=form.price.data,
            renew=form.renew.data,
            expire_date=form.expire_date.data,
            note=form.note.data,
            license_id=license.id,
            modify_date=datetime.now(),
        )

        db.session.add(license_history)
        db.session.commit()
        return redirect(url_for("license._list"))
    return render_template("license/license_enroll.html", lower_tab_list=lower_tab_list, form=form,
                           worker_list=worker_list)


@bp.route("/revise/<int:product_id>/")
@permission_required(['admin'])
def revise(product_id):
    form = LicenseForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.name.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    item_list = License.query.order_by(License.id.asc())
    worker_list = Worker.query.order_by(Worker.name.asc())
    license = License.query.get_or_404(product_id)

    return render_template("license/license_revise.html", item_list=item_list, form=form, license=license,
                           worker_list=worker_list, upper_tab_list=upper_tab_list, lower_tab_list=lower_tab_list)


@bp.route("/revise_complete/<int:product_id>/", methods=["GET", "POST"])
@permission_required(['admin'])
def revise_complete(product_id):
    form = LicenseForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.name.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    license = License.query.get_or_404(product_id)
    worker_list = Worker.query.order_by(Worker.name.asc())

    if request.method == "POST" and form.validate_on_submit():
        for worker in worker_list:
            if worker.nickname == form.nickname.data:
                person_name = worker.name
                break
        expire_date = form.expire_date.data if form.expire_date.data else None
        one_month_before = (
            expire_date - timedelta(days=30) if expire_date else None  # 연산 조건 추가
        )

        # 기존 License 객체의 필드 업데이트
        license.kind = form.kind.data.strip()
        license.sub_kind = form.sub_kind.data.strip()
        license.product_name = form.product_name.data
        license.person = person_name
        license.nickname = form.nickname.data
        license.headquarter = form.headquarter.data
        license.department = form.department.data
        license.buy_date = form.buy_date.data
        license.price = form.price.data
        license.renew = form.renew.data
        license.expire_date = expire_date
        license.note = form.note.data
        license.one_month_before = one_month_before

        license_history = LicenseHistory(
            kind=form.kind.data.strip(),
            sub_kind=form.sub_kind.data.strip(),
            product_name=form.product_name.data,
            person=person_name,
            nickname=form.nickname.data,
            headquarter=form.headquarter.data,
            department=form.department.data,
            buy_date=form.buy_date.data,
            price=form.price.data,
            renew=form.renew.data,
            expire_date=expire_date,
            note=form.note.data,
            license_id=license.id,
            modify_date=datetime.now(),
        )

        db.session.add(license_history)
        db.session.commit()
        return redirect(url_for("license._list", name=form.person.data))
    return render_template("license/license_revise.html", form=form, license=license, upper_tab_list=upper_tab_list,
                           lower_tab_list=lower_tab_list)


@bp.route("/add/")
@permission_required(['admin'])
def add():
    form = TabForm()
    return render_template("license/license_add.html", form=form)


@bp.route("/add_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def add_complete():
    form = TabForm()
    if request.method == "POST" and form.validate_on_submit():
        new_upper_tab_name = form.upper_tab.data.strip()
        upper_tab = UpperTab.query.filter_by(name=new_upper_tab_name).first()

        # 상위탭이 없으면 새로 생성하고 DB에 추가합니다.
        if not upper_tab:
            upper_tab = UpperTab(name=new_upper_tab_name)
            db.session.add(upper_tab)
            db.session.commit()  # 먼저 commit하여 id가 생성되도록 합니다.

        # 하위탭을 상위탭에 연결하여 생성하고 추가합니다.
        new_lower_tab_name = form.lower_tab.data.strip()
        lower_tab = LowerTab(name=new_lower_tab_name, upper_tab=upper_tab)
        db.session.add(lower_tab)
        db.session.commit()
        return redirect(url_for("license._list"))

    return render_template("license/license_add.html", form=form)


@bp.route("/update_expire_date/", methods=['POST'])
@permission_required(['admin'])
def update_expire_date():
    form = UpdateExpireDateForm()
    reference_date = datetime.now()

    if form.validate_on_submit():
        # 문자열을 datetime.date 객체로 변환
        new_expire_date_str = request.form.get("new_expire_date")
        new_expire_date = datetime.strptime(new_expire_date_str, "%Y-%m-%d").date()
        new_one_month_before = datetime.strptime(new_expire_date_str, "%Y-%m-%d").date() - timedelta(days=30)

        selected_ids = request.form.getlist('selected_ids')

        # 선택된 ID들에 대해 만료일 업데이트
        for license_id in selected_ids:
            license_item = License.query.get(license_id)
            if license_item and license_item.renew == "갱신":
                license_item.expire_date = new_expire_date
                license_item.one_month_before = new_one_month_before
                license_history = LicenseHistory(
                    kind=license_item.kind,
                    sub_kind=license_item.sub_kind,
                    product_name=license_item.product_name,
                    person=license_item.person,
                    nickname=license_item.nickname,
                    headquarter=license_item.headquarter,
                    department=license_item.department,
                    buy_date=license_item.buy_date,
                    price=license_item.price,
                    renew=license_item.renew,
                    expire_date=new_expire_date,
                    note=license_item.note,
                    license_id=license_item.id,
                    modify_date=datetime.now(),
                )
                db.session.add(license_history)
        db.session.commit()
        flash("만료일이 성공적으로 업데이트 되었습니다.")
        return redirect(url_for("license._list"))  # 성공 시 목록 페이지로 리디렉션

    # 폼이 유효하지 않은 경우
    flash("잘못된 입력입니다.")
    return redirect(url_for("license._list"))


@bp.route("/list_delete/")
@permission_required(['admin'])
def list_delete():
    form = TabListForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.name.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    return render_template("license/license_list_delete.html", form=form, upper_tab_list=upper_tab_list,
                           lower_tab_list=lower_tab_list)


@bp.route("/list_delete_complete/", methods=['POST'])
@permission_required(['admin'])
def list_delete_complete():
    form = TabListForm()
    if request.form['action'] == '상위탭명 삭제':
        upper_tab_name = request.form.get('upper_tab', '').strip()
        upper_tab = UpperTab.query.filter_by(name=upper_tab_name).first()
        if upper_tab:
            db.session.delete(upper_tab)
            db.session.commit()
        else:
            return "삭제할 항목이 없습니다.", 404
        return redirect(url_for("license._list"))

    elif request.form['action'] == '하위탭명 삭제':
        lower_tab_name = request.form.get('lower_tab', '').strip()
        lower_tab = LowerTab.query.filter_by(name=lower_tab_name).first()
        if lower_tab:
            db.session.delete(lower_tab)
            db.session.commit()
        else:
            return "삭제할 항목이 없습니다.", 404
        return redirect(url_for("license._list"))
    return render_template("license/license_list_delete.html", form=form)


@bp.route("/history/<int:product_id>/")
@permission_required(['admin'])
def history(product_id):
    item_list = LicenseHistory.query.filter_by(license_id=product_id).order_by(
        LicenseHistory.modify_date.desc()).all()
    return render_template("license/license_history.html", item_list=item_list)


@bp.route("/delete/<int:product_id>/")
@permission_required(['admin'])
def delete(product_id):
    item = License.query.filter_by(id=product_id).first()
    db.session.delete(item)
    db.session.commit()
    return render_template("license/license_delete.html", item=item)
