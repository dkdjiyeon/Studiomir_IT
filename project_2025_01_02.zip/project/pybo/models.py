from enum import Enum
from pybo import db
from sqlalchemy import Enum as SQLAEnum


# 데이터 베이스에 저장될 항목들
class UserLevelEnum(Enum):
    basic = "basic"
    read = "read"
    admin = "admin"


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    userid = db.Column(db.String(150), nullable=False, unique=True)
    password = db.Column(db.String(200), nullable=False)
    username = db.Column(db.String(150), nullable=False)
    level = db.Column(SQLAEnum(UserLevelEnum), default=UserLevelEnum.basic)


class Worker(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    nickname = db.Column(db.String(50), nullable=False, unique=True)
    department = db.Column(db.String(50), nullable=False)
    headquarter = db.Column(db.String(50), nullable=False)


class Department(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)


class Headquarter(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)


class Question(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    subject = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text(), nullable=False)
    file_path = db.Column(db.String(300))
    create_date = db.Column(db.DateTime(), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False)
    user = db.relationship("User", backref=db.backref("question_set"))
    modify_date = db.Column(db.DateTime(), nullable=True)
    voter = db.relationship("User", secondary="question_voter", backref=db.backref("question_voter_set"))


class QuestionVoter(db.Model):
    __tablename__ = 'question_voter'  # 테이블 이름 명시
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey('question.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))


class Answer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey("question.id", ondelete="CASCADE"))
    question = db.relationship("Question", backref=db.backref("answer_set"))
    content = db.Column(db.Text(), nullable=False)
    create_date = db.Column(db.DateTime(), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False)
    user = db.relationship("User", backref=db.backref("answer_set"))
    modify_date = db.Column(db.DateTime(), nullable=True)


class Equipment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    kind = db.Column(db.String(50), nullable=False)
    serial = db.Column(db.String(50), nullable=False, unique=True)
    person = db.Column(db.String(50))
    nickname = db.Column(db.String(50))
    department = db.Column(db.String(50))
    headquarter = db.Column(db.String(50))
    ip_add = db.Column(db.String(50))
    buy_date = db.Column(db.DateTime(), nullable=False)
    cpu = db.Column(db.String(50))
    mainboard = db.Column(db.String(50))
    memory = db.Column(db.String(50))
    graphiccard = db.Column(db.String(50))
    ssd = db.relationship('SSD', backref='equipment', lazy=True, cascade="all, delete-orphan")
    equipment_history = db.relationship('EquipmentHistory', backref='equipment_history', lazy=True,
                                        cascade="all, delete-orphan")
    total = db.Column(db.Integer)
    subtotal = db.Column(db.Integer)
    subtotal2 = db.Column(db.Integer)
    vat = db.Column(db.Integer)
    cpu_price = db.Column(db.Integer)
    mainboard_price = db.Column(db.Integer)
    memory_price = db.Column(db.Integer)
    memory_count = db.Column(db.Integer)
    memory_sum = db.Column(db.Integer)
    graphiccard_price = db.Column(db.Integer)
    equip_num = db.Column(db.String(50))
    note = db.Column(db.String(200))
    qr_code_path = db.Column(db.String(200))


class SSD(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50))
    price = db.Column(db.Integer)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'), nullable=False)
    history_id = db.Column(db.Integer, db.ForeignKey('equipment_history.id'))


class EquipmentHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    kind = db.Column(db.String(50))
    serial = db.Column(db.String(50))
    person = db.Column(db.String(50))
    nickname = db.Column(db.String(50))
    department = db.Column(db.String(50))
    headquarter = db.Column(db.String(50))
    ip_add = db.Column(db.String(50))
    buy_date = db.Column(db.DateTime())
    cpu = db.Column(db.String(50))
    mainboard = db.Column(db.String(50))
    memory = db.Column(db.String(50))
    graphiccard = db.Column(db.String(50))
    total = db.Column(db.Integer)
    subtotal = db.Column(db.Integer)
    subtotal2 = db.Column(db.Integer)
    vat = db.Column(db.Integer)
    note = db.Column(db.String(200))
    equip_num = db.Column(db.String(50))
    equipment_id = db.Column(db.Integer, db.ForeignKey("equipment.id"), nullable=False)
    modify_date = db.Column(db.DateTime(), nullable=True)


class Ip(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ip_add = db.Column(db.String(50), nullable=False, unique=True)
    person = db.Column(db.String(50))
    nickname = db.Column(db.String(50))
    headquarter = db.Column(db.String(50))
    department = db.Column(db.String(50))
    section = db.Column(db.String(50))
    serial = db.Column(db.String(50))
    equipment_id = db.Column(db.String(50))
    note = db.Column(db.String(200))


class IpSectionList(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    section = db.Column(db.String(50), nullable=False)


class EquipmentList(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    title = db.Column(db.String(50), nullable=False)


class Schedule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    start_date = db.Column(db.DateTime, nullable=False)
    end_date = db.Column(db.DateTime, nullable=True)
    calendar_id = db.Column(db.String(50), nullable=True)
    background_color = db.Column(db.String(7), nullable=True)  # 추가: 배경색
    border_color = db.Column(db.String(7), nullable=True)  # 추가: 테두리색


class License(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String(50))
    license_id = db.Column(db.String(50))
    kind = db.Column(db.String(50), nullable=False)
    sub_kind = db.Column(db.String(50), nullable=False)
    person = db.Column(db.String(50))
    nickname = db.Column(db.String(50))
    headquarter = db.Column(db.String(50))
    department = db.Column(db.String(50))
    note = db.Column(db.String(50))
    renew = db.Column(db.String(50))
    license_history = db.relationship('LicenseHistory', backref='license_history', lazy=True,
                                      cascade="all, delete-orphan")


class LicenseHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String(50))
    kind = db.Column(db.String(50))
    sub_kind = db.Column(db.String(50))
    person = db.Column(db.String(50))
    nickname = db.Column(db.String(50))
    headquarter = db.Column(db.String(50))
    department = db.Column(db.String(50))
    note = db.Column(db.String(50))
    renew = db.Column(db.String(50))
    license_id = db.Column(db.Integer, db.ForeignKey("license.id"), nullable=False)
    modify_date = db.Column(db.DateTime(), nullable=True)


class UpperTab(db.Model):
    __tablename__ = 'upper_tabs'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False, unique=True)
    lower_tabs = db.relationship('LowerTab', backref='upper_tab', lazy=True, cascade="all, delete-orphan")


class LowerTab(db.Model):
    __tablename__ = 'lower_tabs'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False, unique=True)
    upper_tab_id = db.Column(db.Integer, db.ForeignKey('upper_tabs.id'), nullable=False)


class BuyProduct(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String(50))
    renew = db.Column(db.String(50))
    serial = db.Column(db.String(50))
    buy_date = db.Column(db.DateTime())
    expire_date = db.Column(db.DateTime())
    amount = db.Column(db.Integer)
    price = db.Column(db.Integer)
    subtotal = db.Column(db.Integer)
    vat = db.Column(db.Integer)
    total = db.Column(db.Integer)
    note = db.Column(db.String(50))
    license_number = db.relationship('LicenseNumber', backref='license_number', lazy=True, cascade="all, delete-orphan")


class LicenseNumber(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50))
    sub_kind = db.Column(db.String(50))
    expire_date = db.Column(db.DateTime())
    buyproduct_id = db.Column(db.Integer, db.ForeignKey('buy_product.id'), nullable=False)


class BuyProductRenew(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    renew = db.Column(db.String(50))
