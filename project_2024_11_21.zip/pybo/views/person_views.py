from flask import Blueprint, render_template, request, url_for
from werkzeug.utils import redirect
from pybo.views.main_views import permission_required
from pybo.forms import PersonForm, SearchForm, DepartmentForm, HeadquarterForm
from pybo.models import Equipment, License, LicenseHistory, Worker, EquipmentHistory, Ip, Department, Headquarter
from pybo import db

bp = Blueprint("person", __name__, url_prefix="/person")


@bp.route("/list/")
@permission_required(['admin'])
def _list():
    form = SearchForm()
    worker_list = Worker.query.order_by(Worker.name.asc())
    department_list = Department.query.order_by(Department.name.asc())
    headquarter_list = Headquarter.query.order_by(Headquarter.name.asc())
    item_list = db.session.query(Equipment.person).distinct().order_by(Equipment.person.asc()).all()
    license_list = db.session.query(License.person).distinct().order_by(License.person.asc()).all()

    return render_template('person/person_list.html',
                           item_list=item_list, license_list=license_list, worker_list=worker_list,
                           department_list=department_list, headquarter_list=headquarter_list, form=form)


@bp.route("/search/<string:nickname>/")
@permission_required(['admin'])
def search(nickname):
    form = SearchForm()
    worker_list = Worker.query.order_by(Worker.name.asc())
    filtered_workers = Worker.query.filter_by(nickname=nickname)
    department_list = Department.query.order_by(Department.name.asc())
    headquarter_list = Headquarter.query.order_by(Headquarter.name.asc())
    filtered_equipment = Equipment.query.filter(Equipment.nickname.contains(nickname)).order_by(Equipment.kind.asc()).all()
    filtered_ip = Ip.query.filter(Ip.nickname.contains(nickname)).all()
    filtered_license = License.query.filter(License.nickname.contains(nickname)).all()

    return render_template('person/person_list.html', worker_list=worker_list, filtered_equipment=filtered_equipment,
                           filtered_ip=filtered_ip, filtered_license=filtered_license, department_list=department_list,
                           filtered_workers=filtered_workers, headquarter_list=headquarter_list, form=form)


@bp.route("/search_name/", methods=['GET', 'POST'])
@permission_required(['admin'])
def search_name():
    form = SearchForm()
    name = request.form.get("name")
    worker_list = Worker.query.order_by(Worker.name.asc())
    filtered_workers = Worker.query.filter(Worker.name.contains(name)).all()
    department_list = Department.query.order_by(Department.name.asc())
    headquarter_list = Headquarter.query.order_by(Headquarter.name.asc())

    if name:
        filtered_equipment = Equipment.query.filter(Equipment.person.contains(name)).all()
        filtered_license = License.query.filter(License.person.contains(name)).all()
        filtered_ip = Ip.query.filter(Ip.person.contains(name)).all()
    else:
        filtered_equipment = []
        filtered_license = []
        filtered_ip = []

    return render_template('person/person_list.html', worker_list=worker_list,
                           filtered_equipment=filtered_equipment,
                           filtered_license=filtered_license, filtered_ip=filtered_ip, department_list=department_list,
                           headquarter_list=headquarter_list, filtered_workers=filtered_workers, form=form)


@bp.route("/add/")
@permission_required(['admin'])
def add():
    form = PersonForm()
    department_list = Department.query.order_by(Department.name.asc())
    headquarter_list = Headquarter.query.order_by(Headquarter.name.asc())

    if request.method == "POST" and form.validate_on_submit():
        return redirect(url_for("person._list"))
    return render_template("person/person_add.html", form=form, department_list=department_list,
                           headquarter_list=headquarter_list)


@bp.route("/add_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def add_complete():
    form = PersonForm()
    worker_list = Worker.query.order_by(Worker.name.asc())

    if request.method == "POST" and form.validate_on_submit():
        # 초기 데이터 생성 함수
        user = db.session.query(Worker).filter_by(id=1).first()
        if not user:
            # id=1인 새로운 사용자 생성
            default_user = Worker(id=1, name="None", nickname="None", department="None", headquarter="None")
            db.session.add(default_user)
            db.session.commit()

        if Worker.query.filter_by(nickname=form.nickname.data).first():
            return "이미 아이디가 존재합니다.", 404
        worker = Worker(name=form.name.data, nickname=form.nickname.data, department=form.department.data,
                        headquarter=form.headquarter.data)
        db.session.add(worker)
        db.session.commit()
        return redirect(url_for("person._list"))
    return render_template("person/person_add.html", form=form, worker_list=worker_list)


@bp.route("/revise/<int:product_id>/")
@permission_required(['admin'])
def revise(product_id):
    form = PersonForm()
    worker = Worker.query.filter_by(id=product_id).first()
    worker_list = Worker.query.order_by(Worker.name.asc())
    department_list = Department.query.order_by(Department.name.asc())
    headquarter_list = Headquarter.query.order_by(Headquarter.name.asc())

    if request.method == "POST" and form.validate_on_submit():
        return redirect(url_for("person._list"))
    return render_template("person/person_revise.html", form=form, worker_list=worker_list,
                           headquarter_list=headquarter_list, department_list=department_list, worker=worker)


@bp.route("/revise_complete/<int:product_id>/", methods=["GET", "POST"])
@permission_required(['admin'])
def revise_complete(product_id):
    form = PersonForm()
    worker = Worker.query.get_or_404(product_id)
    filtered_equipment = Equipment.query.filter(Equipment.nickname.contains(worker.nickname)).all()
    filtered_license = License.query.filter(License.nickname.contains(worker.nickname)).all()
    filtered_ip = Ip.query.filter(Ip.nickname.contains(worker.nickname)).all()

    if request.method == "POST" and form.validate_on_submit():
        worker.name = form.name.data
        worker.nickname = form.nickname.data
        worker.headquarter = form.headquarter.data
        worker.department = form.department.data

        for equipment in filtered_equipment:
            equipment.person = form.name.data
            equipment.nickname = form.nickname.data
            equipment.headquarter = form.headquarter.data
            equipment.department = form.department.data

        for license in filtered_license:
            license.person = form.name.data
            license.nickname = form.nickname.data
            license.headquarter = form.headquarter.data
            license.department = form.department.data

        for ip in filtered_ip:
            ip.person = form.name.data
            ip.nickname = form.nickname.data
            ip.headquarter = form.headquarter.data
            ip.department = form.department.data

        db.session.commit()
        return redirect(url_for("person._list"))
    return render_template("person/person_revise.html", form=form)


@bp.route("/depart_add/")
@permission_required(['admin'])
def depart_add():
    form = DepartmentForm()

    if request.method == "POST" and form.validate_on_submit():
        return redirect(url_for("person._list"))
    return render_template("person/person_depart_add.html", form=form)


@bp.route("/depart_add_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def depart_add_complete():
    form = DepartmentForm()
    name = request.form['action']

    if request.method == "POST" and form.validate_on_submit():

        if name == "추가":
            # 초기 데이터 생성 함수
            user = db.session.query(Department).filter_by(id=1).first()
            if not user:
                # id=1인 새로운 사용자 생성
                default_user = Department(id=1, name="None")
                db.session.add(default_user)
                db.session.commit()

            department = Department(name=form.name.data)
            db.session.add(department)
            db.session.commit()
            return redirect(url_for('person._list'))
        elif name == "삭제":
            department_list = Department.query.filter_by(name=form.name.data).first()

            if department_list:
                db.session.delete(department_list)
                db.session.commit()
                return redirect(url_for("person._list"))
            else:
                # 삭제할 항목이 없는 경우 처리
                return "삭제할 항목이 없습니다.", 404

    return render_template("person/person_depart_add.html", form=form)


@bp.route("/headquarter_add/")
@permission_required(['admin'])
def headquarter_add():
    form = HeadquarterForm()

    if request.method == "POST" and form.validate_on_submit():
        return redirect(url_for("person._list"))
    return render_template("person/person_headquarter_add.html", form=form)


@bp.route("/headquarter_add_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def headquarter_add_complete():
    form = HeadquarterForm()
    name = request.form['action']

    if request.method == "POST" and form.validate_on_submit():

        if name == "추가":
            # 초기 데이터 생성 함수
            user = db.session.query(Headquarter).filter_by(id=1).first()
            if not user:
                # id=1인 새로운 사용자 생성
                default_user = Headquarter(id=1, name="None")
                db.session.add(default_user)
                db.session.commit()

            headquarter = Headquarter(name=form.name.data)
            db.session.add(headquarter)
            db.session.commit()
            return redirect(url_for('person._list'))
        elif name == "삭제":
            headquarter_list = Headquarter.query.filter_by(name=form.name.data).first()

            if headquarter_list:
                db.session.delete(headquarter_list)
                db.session.commit()
                return redirect(url_for("person._list"))
            else:
                # 삭제할 항목이 없는 경우 처리
                return "삭제할 항목이 없습니다.", 404

    return render_template("person/person_headquarter_add.html", form=form)


@bp.route("/history/<int:product_id>/")
@permission_required(['admin'])
def history(product_id):
    worker = Worker.query.filter_by(id=product_id).first()
    item_list = EquipmentHistory.query.filter_by(nickname=worker.nickname).order_by(
        EquipmentHistory.modify_date.desc()).all()
    license_list = LicenseHistory.query.filter_by(nickname=worker.nickname).order_by(
        LicenseHistory.modify_date.desc()).all()
    return render_template("person/person_history.html", item_list=item_list, license_list=license_list)


@bp.route("/delete/<int:product_id>/")
@permission_required(['admin'])
def delete(product_id):
    worker = Worker.query.filter_by(id=product_id).first()
    if worker.name == "None":
        return "기본 설정이므로 삭제할 수 없습니다", 404

    filtered_equipment = Equipment.query.filter(Equipment.nickname.contains(worker.nickname)).all()
    filtered_equipment_history = EquipmentHistory.query.filter(
        EquipmentHistory.nickname.contains(worker.nickname)).all()
    filtered_license = License.query.filter(License.nickname.contains(worker.nickname)).all()
    filtered_license_history = LicenseHistory.query.filter(LicenseHistory.nickname.contains(worker.nickname)).all()
    filtered_ip = Ip.query.filter(Ip.nickname.contains(worker.nickname)).all()
    for equipment in filtered_equipment:
        equipment.person = None
        equipment.nickname = None
        equipment.department = None
        equipment.ip_add = None

    for equipment_history in filtered_equipment_history:
        db.session.delete(equipment_history)

    for license in filtered_license:
        license.person = None
        license.nickname = None
        license.department = None

    for license_history in filtered_license_history:
        db.session.delete(license_history)

    for ip in filtered_ip:
        db.session.delete(ip)

    db.session.delete(worker)
    db.session.commit()
    return render_template("person/person_delete.html", worker=worker)
