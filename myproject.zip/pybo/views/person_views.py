from flask import Blueprint, render_template, request
from pybo.views.main_views import permission_required
from pybo.models import Equipment, EquipmentList
from pybo import db

bp = Blueprint("person", __name__, url_prefix="/person")


@bp.route("/list/")
@permission_required(['read', 'admin'])
def _list():
    search_name = request.args.get('name')
    item_list = db.session.query(Equipment.person).distinct().order_by(Equipment.person.asc()).all()
    if search_name:
        # 데이터베이스에서 이름이 검색어와 일치하는 사람을 필터링
        filtered_people = Equipment.query.filter(Equipment.person.contains(search_name)).all()
    else:
        filtered_people = []  # 검색어가 없을 경우 빈 리스트 반환
    return render_template('person/person_list.html', people=filtered_people, item_list=item_list)


@bp.route("/list/revise/<int:p_id>/")
@permission_required(['read', 'admin'])
def revise(p_id):
    equipment = Equipment.query.get_or_404(p_id)
    form = Equipment()
    item_list = EquipmentList.query.order_by(EquipmentList.id.asc())
    return render_template('equipment/equipment_revise.html', form=form, equipment=equipment, item_list=item_list)
