from pybo.models import UpperTab, LowerTab, License, LicenseHistory, Worker
from pybo.forms import LicenseForm, TabForm, TabListForm
from flask import Blueprint, render_template, request, url_for
from werkzeug.utils import redirect
from pybo import db
from pybo.views.main_views import permission_required
from datetime import datetime, timedelta

bp = Blueprint("license", __name__, url_prefix="/license")


@bp.route("/list/")
@permission_required(['admin'])
def _list():
    upper_tab_list = UpperTab.query.order_by(UpperTab.id.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.id.asc())
    license_list = License.query.order_by(License.person.asc())
    item_count = {}
    not_enroll_count = {}
    expire_count = {}
    reference_date = datetime.now()

    # 하위탭별 라이센스 필터링 데이터 준비
    filtered_license_list = {}
    for lower_tab in lower_tab_list:
        # 각 하위탭의 라이센스만 필터링하여 저장
        filtered_license_list[lower_tab.name] = License.query.filter_by(sub_kind=lower_tab.name).all()

        # 각 하위탭의 개수, 미지정 개수, 만료 개수 계산
        lower_tab_count = len(filtered_license_list[lower_tab.name])
        item_count[lower_tab.name] = lower_tab_count
        lower_tab_not_enroll_count = len([l for l in filtered_license_list[lower_tab.name] if l.person == "None"])
        not_enroll_count[lower_tab.name] = lower_tab_not_enroll_count
        lower_tab_expire_count = len([l for l in filtered_license_list[lower_tab.name] if
                                      l.one_month_before and l.one_month_before < reference_date])
        expire_count[lower_tab.name] = lower_tab_expire_count

    return render_template("license/license_list.html", upper_tab_list=upper_tab_list, lower_tab_list=lower_tab_list,
                           item_count=item_count, not_enroll_count=not_enroll_count, expire_count=expire_count,
                           reference_date=reference_date, filtered_license_list=filtered_license_list,
                           license_list=license_list)


@bp.route("/enroll/")
@permission_required(['admin'])
def enroll():
    form = LicenseForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.name.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    worker_list = Worker.query.order_by(Worker.name.asc())
    return render_template("license/license_enroll.html", form=form, worker_list=worker_list,
                           upper_tab_list=upper_tab_list,
                           lower_tab_list=lower_tab_list)


@bp.route("/enroll_complete/", methods=("GET", "POST"))
@permission_required(['admin'])
def enroll_complete():
    form = LicenseForm()
    lower_tab_list = LowerTab.query.order_by(LowerTab.id.asc())
    worker_list = Worker.query.order_by(Worker.name.asc())

    if request.method == "POST" and form.validate_on_submit():
        for worker in worker_list:
            if worker.nickname == form.nickname.data:
                person_name = worker.name
                break
        if form.expire_date.data is None:
            one_month_before = None
        else:
            one_month_before = form.expire_date.data - timedelta(days=30)

        license = License(
            kind=form.kind.data,
            sub_kind=form.sub_kind.data,
            product_name=form.product_name.data,
            person=person_name,
            nickname=form.nickname.data,
            headquarter=form.headquarter.data,
            department=form.department.data,
            buy_date=form.buy_date.data,
            price=form.price.data,
            renew=form.renew.data,
            expire_date=form.expire_date.data,
            one_month_before=one_month_before,
            note=form.note.data,
        )

        db.session.add(license)
        db.session.commit()
        license_history = LicenseHistory(
            kind=form.kind.data,
            sub_kind=form.sub_kind.data,
            product_name=form.product_name.data,
            person=person_name,
            nickname=form.nickname.data,
            headquarter=form.headquarter.data,
            department=form.department.data,
            buy_date=form.buy_date.data,
            price=form.price.data,
            renew=form.renew.data,
            expire_date=form.expire_date.data,
            note=form.note.data,
            license_id=license.id,
            modify_date=datetime.now(),
        )

        db.session.add(license_history)
        db.session.commit()
        return redirect(url_for("license._list"))
    return render_template("license/license_enroll.html", lower_tab_list=lower_tab_list, form=form,
                           worker_list=worker_list)


@bp.route("/revise/<int:product_id>/")
@permission_required(['admin'])
def revise(product_id):
    form = LicenseForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.name.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    item_list = License.query.order_by(License.id.asc())
    worker_list = Worker.query.order_by(Worker.name.asc())
    license = License.query.get_or_404(product_id)

    return render_template("license/license_revise.html", item_list=item_list, form=form, license=license,
                           worker_list=worker_list, upper_tab_list=upper_tab_list, lower_tab_list=lower_tab_list)


@bp.route("/revise_complete/<int:product_id>/", methods=("GET", "POST"))
@permission_required(['admin'])
def revise_complete(product_id):
    form = LicenseForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.name.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    license = License.query.get_or_404(product_id)
    worker_list = Worker.query.order_by(Worker.name.asc())

    if request.method == "POST" and form.validate_on_submit():
        for worker in worker_list:
            if worker.nickname == form.nickname.data:
                person_name = worker.name
                break
        if form.expire_date.data is None:
            one_month_before = None
        else:
            one_month_before = form.expire_date.data - timedelta(days=30)

        # 기존 License 객체의 필드 업데이트
        license.kind = form.kind.data
        license.sub_kind = form.sub_kind.data
        license.product_name = form.product_name.data
        license.person = person_name
        license.nickname = form.nickname.data
        license.headquarter = form.headquarter.data
        license.department = form.department.data
        license.buy_date = form.buy_date.data
        license.price = form.price.data
        license.renew = form.renew.data
        license.expire_date = form.expire_date.data
        license.note = form.note.data
        license.one_month_before = one_month_before

        license_history = LicenseHistory(
            kind=form.kind.data,
            sub_kind=form.sub_kind.data,
            product_name=form.product_name.data,
            person=person_name,
            nickname=form.nickname.data,
            headquarter=form.headquarter.data,
            department=form.department.data,
            buy_date=form.buy_date.data,
            price=form.price.data,
            renew=form.renew.data,
            expire_date=form.expire_date.data,
            note=form.note.data,
            license_id=license.id,
            modify_date=datetime.now(),
        )

        db.session.add(license_history)
        db.session.commit()
        return redirect(url_for("license._list", name=form.person.data))
    return render_template("license/license_revise.html", form=form, license=license, upper_tab_list=upper_tab_list,
                           lower_tab_list=lower_tab_list)


@bp.route("/add/")
@permission_required(['admin'])
def add():
    form = TabForm()
    return render_template("license/license_add.html", form=form)


@bp.route("/add_complete/", methods=("GET", "POST"))
@permission_required(['admin'])
def add_complete():
    form = TabForm()
    if request.method == "POST" and form.validate_on_submit():
        upper_tab = UpperTab.query.filter_by(name=form.upper_tab.data).first()

        # 상위탭이 없으면 새로 생성하고 DB에 추가합니다.
        if not upper_tab:
            upper_tab = UpperTab(name=form.upper_tab.data)
            db.session.add(upper_tab)
            db.session.commit()  # 먼저 commit하여 id가 생성되도록 합니다.

        # 하위탭을 상위탭에 연결하여 생성하고 추가합니다.
        lower_tab = LowerTab(name=form.lower_tab.data, upper_tab=upper_tab)
        db.session.add(lower_tab)
        db.session.commit()
        return redirect(url_for("license._list"))

    return render_template("license/license_add.html", form=form)


@bp.route("/list_delete/")
@permission_required(['admin'])
def list_delete():
    form = TabListForm()
    upper_tab_list = UpperTab.query.order_by(UpperTab.name.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    return render_template("license/license_list_delete.html", form=form, upper_tab_list=upper_tab_list,
                           lower_tab_list=lower_tab_list)


@bp.route("/list_delete_complete/", methods=['POST'])
@permission_required(['admin'])
def list_delete_complete():
    form = TabListForm()
    if request.form['action'] == '상위탭명 삭제':
        upper_tab_name = request.form.get('upper_tab')
        upper_tab = UpperTab.query.filter_by(name=upper_tab_name).first()
        if upper_tab:
            db.session.delete(upper_tab)
            db.session.commit()
        else:
            return "삭제할 항목이 없습니다.", 404
        return redirect(url_for("license._list"))

    elif request.form['action'] == '하위탭명 삭제':
        lower_tab_name = request.form.get('lower_tab')
        lower_tab = LowerTab.query.filter_by(name=lower_tab_name).first()
        if lower_tab:
            db.session.delete(lower_tab)
            db.session.commit()
        else:
            return "삭제할 항목이 없습니다.", 404
        return redirect(url_for("license._list"))
    return render_template("license/license_list_delete.html", form=form)


@bp.route("/history/<int:product_id>/")
@permission_required(['admin'])
def history(product_id):
    item_list = LicenseHistory.query.filter_by(license_id=product_id).order_by(
        LicenseHistory.modify_date.desc()).all()
    return render_template("license/license_history.html", item_list=item_list)


@bp.route("/delete/<int:product_id>/")
@permission_required(['admin'])
def delete(product_id):
    item = License.query.filter_by(id=product_id).first()
    db.session.delete(item)
    db.session.commit()
    return render_template("license/license_delete.html", item=item)
