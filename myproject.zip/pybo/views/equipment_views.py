from flask import Blueprint, render_template, request, url_for, jsonify
from werkzeug.utils import redirect
from pybo.forms import ProductForm, ItemForm
from pybo import db
from pybo.models import Equipment, EquipmentList, EquipmentHistory
from pybo.views.main_views import permission_required
from datetime import datetime

bp = Blueprint("equipment", __name__, url_prefix="/equipment")


@bp.route("/list/")
@permission_required(['admin'])
def _list():
    item_list = EquipmentList.query.order_by(EquipmentList.id.asc())
    detail_list = []
    item_count = []
    not_enroll_count = []
    for item in item_list:
        detail_list.extend(Equipment.query.filter_by(kind=item.name).all())
        item_count.append(Equipment.query.filter_by(kind=item.name).count())
        not_enroll_count.append(Equipment.query.filter(Equipment.kind == item.name, Equipment.person == '').count())


    return render_template("equipment/equipment_list.html", item_list=item_list, detail_list=detail_list,
                           item_count=item_count, not_enroll_count=not_enroll_count)


@bp.route("/enroll/")
@permission_required(['admin'])
def enroll():
    form = ProductForm()
    item_list = EquipmentList.query.order_by(EquipmentList.id.asc())
    return render_template("equipment/equipment_enroll.html", item_list=item_list, form=form)


@bp.route("/enroll_complete/", methods=("GET", "POST"))
@permission_required(['admin'])
def enroll_complete():
    form = ProductForm()
    item_list = EquipmentList.query.order_by(EquipmentList.id.asc())

    if request.method == "POST" and form.validate_on_submit():
        equipment = Equipment(
            kind=form.kind.data,
            product_name=form.product_name.data,
            person=form.person.data,
            note=form.note.data,
            buy_date=form.buy_date.data,
            enroll_date=form.enroll_date.data,
        )

        db.session.add(equipment)
        db.session.commit()
        equipment_history = EquipmentHistory(
            kind=form.kind.data,
            product_name=form.product_name.data,
            person=form.person.data,
            buy_date=form.buy_date.data,
            enroll_date=form.enroll_date.data,
            equipment_id=equipment.id,
            modify_date=datetime.now(),
        )

        db.session.add(equipment_history)
        db.session.commit()
        return redirect(url_for("equipment._list"))
    return render_template("equipment/equipment_enroll.html", item_list=item_list, form=form)


@bp.route("/revise_complete/<int:equipment_id>/", methods=("GET", "POST"))
@permission_required(['admin'])
def revise_complete(equipment_id):
    form = ProductForm()
    item_list = EquipmentList.query.order_by(EquipmentList.id.asc())
    equipment = Equipment.query.get_or_404(equipment_id)
    if request.method == "POST" and form.validate_on_submit():
        # 기존 Equipment 객체의 필드 업데이트
        equipment.kind = form.kind.data
        equipment.product_name = form.product_name.data
        equipment.person = form.person.data
        equipment.note = form.note.data
        equipment.buy_date = form.buy_date.data
        equipment.enroll_date = form.enroll_date.data

        equipment_history = EquipmentHistory(
            kind=form.kind.data,
            product_name=form.product_name.data,
            person=form.person.data,
            buy_date=form.buy_date.data,
            enroll_date=form.enroll_date.data,
            equipment_id=equipment_id,
            modify_date=datetime.now(),
        )

        db.session.add(equipment_history)
        db.session.commit()
        return redirect(url_for("equipment._list", name=form.person.data))
    return render_template("equipment/equipment_revise.html", item_list=item_list, form=form, equipment=equipment)


@bp.route("/add/")
@permission_required(['admin'])
def add():
    form = ItemForm()
    return render_template("equipment/equipment_add.html", form=form)


@bp.route("/add_complete/", methods=("GET", "POST"))
@permission_required(['admin'])
def add_complete():
    itemform = ItemForm()
    name = request.form['action']
    if request.method == "POST" and itemform.validate_on_submit():
        if name == "추가":
            equipment_list = EquipmentList(name=itemform.name.data, )
            db.session.add(equipment_list)
            db.session.commit()
            return redirect(url_for("equipment._list"))
        elif name == "삭제":
            equipment_list = EquipmentList.query.filter_by(name=itemform.name.data).first()

            if equipment_list:
                db.session.delete(equipment_list)
                db.session.commit()
                return redirect(url_for("equipment._list"))
            else:
                # 삭제할 항목이 없는 경우 처리
                return "삭제할 항목이 없습니다.", 404
    return render_template("equipment/equipment_add.html", form=itemform)


@bp.route("/list/detail/<string:item>/")
@permission_required(['admin'])
def detail(item):
    product_list = Equipment.query.filter_by(item=item).all()
    return render_template("equipment/equipment_list.html", product_list=product_list)


@bp.route("/history/<int:product_id>/")
@permission_required(['admin'])
def history(product_id):
    item_list = EquipmentHistory.query.filter_by(equipment_id=product_id).order_by(
        EquipmentHistory.modify_date.desc()).all()
    return render_template("equipment/equipment_history.html", item_list=item_list)


@bp.route("/delete/<int:product_id>/")
@permission_required(['admin'])
def delete(product_id):
    item = Equipment.query.filter_by(id=product_id).first()

    db.session.delete(item)
    db.session.commit()
    return render_template("equipment/equipment_delete.html", item=item)



