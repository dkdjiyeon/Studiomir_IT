from flask import Blueprint, render_template
from pybo.views.main_views import permission_required

bp = Blueprint("stock", __name__, url_prefix="/stock")


@bp.route("/list/")
@permission_required(['admin'])
def _list():

    return render_template('stock/stock_list.html')


