import csv
import io
from datetime import datetime, timedelta

from flask import Blueprint, render_template, request, url_for, send_file
from pybo import db
from pybo.forms import BuyForm, RenewForm
from pybo.models import BuyProduct, BuyProductRenew, LowerTab, LicenseNumber
from pybo.views.main_views import permission_required
from sqlalchemy import or_
from werkzeug.utils import redirect

bp = Blueprint("purchase", __name__, url_prefix="/purchase")


@bp.route("/list/")
@permission_required(['admin'])
def _list():
    reference_date = datetime.now()
    product_list = BuyProduct.query.filter(or_(
        BuyProduct.expire_date >= reference_date,
        BuyProduct.expire_date.is_(None)
    )).order_by(BuyProduct.product_name)

    return render_template('purchase/purchase_list.html', product_list=product_list, reference_date=reference_date,
                           timedelta=timedelta)


@bp.route("/enroll/")
@permission_required(['admin'])
def enroll():
    form = BuyForm()
    renew_list = BuyProductRenew.query.order_by(BuyProductRenew.renew.asc())
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())

    return render_template('purchase/purchase_enroll.html', renew_list=renew_list, lower_tab_list=lower_tab_list,
                           form=form)


@bp.route("/enroll_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def enroll_complete():
    form = BuyForm()
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())

    if request.method == "POST" and form.validate_on_submit():
        if form.renew.data == "라이센스(갱신)" and form.expire_date.data is None:
            return "라이센스(갱신)인 경우, 만료일을 기입해 주세요", 404

        amount_int = form.amount.data.replace(",", "")
        price_int = form.price.data.replace(",", "")
        vat_int = form.vat.data.replace(",", "")
        total_int = form.total.data.replace(",", "")
        license_list = request.form.getlist('license_num[]')

        values = [amount_int, price_int, vat_int, total_int]

        for value in values:
            if not value.isdigit():
                return "금액은 숫자로만 입력하세요.", 404

        buy_product = BuyProduct(
            product_name=form.product_name.data,
            serial=form.serial.data,
            renew=form.renew.data,
            buy_date=form.buy_date.data,
            expire_date=form.expire_date.data,
            amount=form.amount.data,
            price=form.price.data,
            subtotal=form.subtotal.data,
            vat=form.vat.data,
            total=form.total.data,
            note=form.note.data,
        )

        db.session.add(buy_product)
        db.session.commit()

        for license in license_list:
            if license:
                new_license = LicenseNumber(
                    name=license,
                    sub_kind=form.product_name.data,
                    expire_date=form.expire_date.data,
                    buyproduct_id=buy_product.id,
                )
                db.session.add(new_license)
        db.session.commit()
        return redirect(url_for("purchase._list"))
    return render_template('purchase/purchase_enroll.html', form=form, lower_tab_list=lower_tab_list)


@bp.route("/revise/<int:product_id>/")
@permission_required(['admin'])
def revise(product_id):
    form = BuyForm()
    buy_product = BuyProduct.query.get_or_404(product_id)
    license_number_list = LicenseNumber.query.filter_by(buyproduct_id=product_id).all()
    return render_template('purchase/purchase_revise.html', buy_product=buy_product,
                           license_number_list=license_number_list,
                           form=form)


@bp.route("/revise_complete/<int:product_id>/", methods=["GET", "POST"])
@permission_required(['admin'])
def revise_complete(product_id):
    form = BuyForm()
    product_list = BuyProduct.query.order_by(BuyProduct.product_name.asc())
    license_number = LicenseNumber.query.filter_by(buyproduct_id=product_id).all()
    reference_date = datetime.now()

    if request.method == "POST" and form.validate_on_submit():
        # 기존 license_number 삭제
        for l in license_number:
            db.session.delete(l)
        db.session.commit()

        license_list = request.form.getlist('license_num[]')
        for license in license_list:
            if license:
                new_license = LicenseNumber(
                    name=license,
                    sub_kind=form.product_name.data,
                    expire_date=form.expire_date.data,
                    buyproduct_id=product_id,
                )
                db.session.add(new_license)
        db.session.commit()
        return redirect(url_for("purchase._list"))
    return render_template('purchase/purchase_list.html', product_list=product_list, reference_date=reference_date,
                           timedelta=timedelta)


@bp.route("/add/")
@permission_required(['admin'])
def add():
    form = BuyForm()
    return render_template('purchase/purchase_add.html', form=form)


@bp.route("/add_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def add_complete():
    form = RenewForm()
    renew = request.form['action']
    if request.method == "POST" and form.validate_on_submit():
        if renew == "추가":
            renew_list = BuyProductRenew(renew=form.renew.data)
            db.session.add(renew_list)
            db.session.commit()
            return redirect(url_for("purchase._list"))
        elif renew == "삭제":
            if form.renew.data == "라이센스(갱신)" or form.renew.data == "라이센스(영구)":
                return "기본항목이므로 삭제할 수 없습니다", 404
            renew_list = BuyProductRenew.query.filter_by(renew=form.renew.data).first()
            if renew_list:
                db.session.delete(renew_list)
                db.session.commit()
                return redirect(url_for("purchase._list"))
            else:
                # 삭제할 항목이 없는 경우 처리
                return "삭제할 항목이 없습니다.", 404
    return render_template("purchase/purchase_add.html", form=form)


@bp.route("/delete/<int:product_id>/")
@permission_required(['admin'])
def delete(product_id):
    item = BuyProduct.query.filter_by(id=product_id).first()
    db.session.delete(item)
    db.session.commit()
    return render_template("purchase/purchase_delete.html", item=item)


@bp.route("/download_license/")
@permission_required(['admin'])
def download_license():
    purchase_list = BuyProduct.query.order_by(BuyProduct.product_name.asc())

    purchase_data = []
    for purchase in purchase_list:
        # 년-월-일 형식으로 추출
        formatted_buy_date = purchase.buy_date.strftime("%Y-%m-%d")
        formatted_expire_date = purchase.expire_date.strftime("%Y-%m-%d")

        purchase_data.append(
            {"품명": purchase.product_name, "품목": purchase.renew, "문서번호": purchase.serial, "구매일": formatted_buy_date,
             "만료일": formatted_expire_date, "수량": purchase.amount, "단가": purchase.price, "금액": purchase.subtotal,
             "VAT": purchase.vat, "총금액": purchase.total, "비고": purchase.note})

    # CSV 파일을 메모리에 생성
    output = io.StringIO()
    writer = csv.writer(output)

    # 장비 데이터 작성
    writer.writerow(["구매 리스트"])
    writer.writerow(["품명", "품목", "문서번호", "구매일", "만료일", "수량", "단가", "금액", "VAT", "총금액", "비고"])

    for row in purchase_data:
        writer.writerow(
            [row['품명'], row['품목'], row['문서번호'], row['구매일'], row['만료일'], row['수량'], row['단가'], row['금액'], row['VAT'],
             row['총금액'], row['비고']])

    writer.writerow([])  # 빈 줄 추가
    writer.writerow([])  # 빈 줄 추가

    output.seek(0)

    # 파일 이름 설정
    filename = f"PurchaseList_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

    return send_file(io.BytesIO(output.getvalue().encode('utf-8-sig')),
                     mimetype='text/csv',
                     as_attachment=True,
                     download_name=filename)


@bp.route('/sort/', methods=['GET'])
@permission_required(['admin'])
def sort():
    reference_date = datetime.now()
    sort_column = request.args.get('sort_column', 'product_name')  # 기본값을 'product_name'으로 설정
    renew_type = request.args.get('renew_type', None)  # renew_type이 있는 경우 필터링

    query = BuyProduct.query  # BuyProduct 테이블을 쿼리

    if sort_column == 'product_name':
        query = BuyProduct.query.filter(or_(
            BuyProduct.expire_date >= reference_date,
            BuyProduct.expire_date.is_(None)
        )
        )
    elif sort_column == 'renew1':
        query = query.filter(BuyProduct.expire_date >= reference_date, BuyProduct.renew == '라이센스(갱신)')
    elif sort_column == 'renew2':
        query = query.filter(BuyProduct.renew == '라이센스(영구)')
    elif sort_column == 'expire_date':
        query = query.filter(BuyProduct.expire_date < reference_date)

    # 쿼리 결과를 가져와서 템플릿에 전달
    product_list = query.order_by(BuyProduct.product_name).all()

    return render_template('purchase/purchase_list.html', product_list=product_list, reference_date=reference_date,
                           timedelta=timedelta)
