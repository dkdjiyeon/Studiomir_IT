from pybo.forms import BuyForm, RenewForm
from pybo.models import BuyProduct, BuyProductRenew
from flask import Blueprint, render_template, request, url_for
from werkzeug.utils import redirect
from pybo import db
from pybo.views.main_views import permission_required
from datetime import datetime, timedelta

bp = Blueprint("purchase", __name__, url_prefix="/purchase")


@bp.route("/list/")
@permission_required(['admin'])
def _list():
    product_list = BuyProduct.query.order_by(BuyProduct.product_name.asc())
    reference_date = datetime.now()

    return render_template('purchase/purchase_list.html', product_list=product_list, reference_date=reference_date,
                           timedelta=timedelta)


@bp.route("/enroll/")
@permission_required(['admin'])
def enroll():
    form = BuyForm()
    renew_list = BuyProductRenew.query.order_by(BuyProductRenew.renew.asc())
    return render_template('purchase/purchase_enroll.html', renew_list=renew_list, form=form)


@bp.route("/enroll_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def enroll_complete():
    form = BuyForm()
    if request.method == "POST" and form.validate_on_submit():
        if form.renew.data == "라이센스(갱신)" and form.expire_date.data is None:
            return "라이센스(갱신)인 경우, 만료일을 기입해 주세요", 404

        buy_product = BuyProduct(
            product_name=form.product_name.data,
            serial=form.serial.data,
            renew=form.renew.data,
            buy_date=form.buy_date.data,
            expire_date=form.expire_date.data,
            amount=form.amount.data,
            price=form.price.data,
            vat=form.vat.data,
            total=form.total.data,
            note=form.note.data,
        )

        db.session.add(buy_product)
        db.session.commit()
        return redirect(url_for("purchase._list"))
    return render_template('purchase/purchase_enroll.html', form=form)


@bp.route("/add/")
@permission_required(['admin'])
def add():
    form = BuyForm()
    return render_template('purchase/purchase_add.html', form=form)


@bp.route("/add_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def add_complete():
    form = RenewForm()
    renew = request.form['action']
    if request.method == "POST" and form.validate_on_submit():
        if renew == "추가":
            renew_list = BuyProductRenew(renew=form.renew.data)
            db.session.add(renew_list)
            db.session.commit()
            return redirect(url_for("purchase._list"))
        elif renew == "삭제":
            if form.renew.data == "라이센스(갱신)" or form.renew.data == "라이센스(영구)":
                return "기본항목이므로 삭제할 수 없습니다", 404
            renew_list = BuyProductRenew.query.filter_by(renew=form.renew.data).first()
            if renew_list:
                db.session.delete(renew_list)
                db.session.commit()
                return redirect(url_for("purchase._list"))
            else:
                # 삭제할 항목이 없는 경우 처리
                return "삭제할 항목이 없습니다.", 404
    return render_template("purchase/purchase_add.html", form=form)


@bp.route("/delete/<int:product_id>/")
@permission_required(['admin'])
def delete(product_id):
    item = BuyProduct.query.filter_by(id=product_id).first()
    db.session.delete(item)
    db.session.commit()
    return render_template("purchase/purchase_delete.html", item=item)