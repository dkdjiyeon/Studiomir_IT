import os

import config
from flask import Flask
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect
from sqlalchemy import MetaData

naming_convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(column_0_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

db = SQLAlchemy(metadata=MetaData(naming_convention=naming_convention))
migrate = Migrate()


def create_app():
    app = Flask(__name__)
    app.config.from_object(config)

    # 사진 설정
    app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static/uploads')
    # pdf 설정
    app.config['PDF_FOLDER'] = os.path.join(app.root_path, 'static/pdf')
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

    csrf = CSRFProtect(app)

    # 특정 블루프린트에서 CSRF 보호 비활성화
    from pybo.views.schedule_views import bp as schedule_bp
    csrf.exempt(schedule_bp)

    # ORM 초기화
    db.init_app(app)
    migrate.init_app(app, db,
                     render_as_batch=True if app.config["SQLALCHEMY_DATABASE_URI"].startswith("sqlite") else False)

    # 모델 가져오기
    from . import models
    from sqlalchemy import event
    from sqlalchemy.orm import Session
    from sqlalchemy.orm.attributes import get_history
    from .views import question_views

    # 데이터베이스 초기값 설정
    # CLI 명령어 등록
    from .seeds import seed_data
    app.cli.add_command(seed_data)

    # is_image 함수를 Jinja 템플릿에서 사용할 수 있도록 등록
    app.jinja_env.globals['is_image'] = question_views.is_image

    # 전산장비 변경 시 아이피 연동
    @event.listens_for(models.Equipment, 'after_update')
    def sync_person_with_ip(mapper, connection, target):
        with Session(bind=connection) as session:
            # ip_add 필드의 변경 전 값을 가져옴
            old_ip_add = get_history(target, 'ip_add').deleted[0] if get_history(target, 'ip_add').deleted else None

            # 이전 IP 주소가 있으면, 해당 IP 레코드를 업데이트
            if old_ip_add:
                old_ip = session.query(models.Ip).filter_by(ip_add=old_ip_add).first()
                if old_ip:
                    old_ip.person = None  # 또는 적절한 기본값으로 설정
                    old_ip.nickname = None
                    old_ip.headquarter = None
                    old_ip.department = None
                    old_ip.serial = None
                    old_ip.equipment_id = None
                    old_ip.note = None

            # 새로운 IP 주소에 대한 업데이트
            ip = session.query(models.Ip).filter_by(ip_add=target.ip_add).first()
            if ip:
                ip.person = target.person
                ip.nickname = target.nickname
                ip.headquarter = target.headquarter
                ip.department = target.department
                ip.serial = target.serial
                ip.equipment_id = target.id
                ip.note = target.note

            session.commit()

    # 블루프린트 등록
    from .views import (
        main_views,
        homepage_views,
        schedule_views,
        question_views,
        answer_views,
        auth_views,
        equipment_views,
        person_views,
        license_views,
        ip_views,
        admin_views,
        purchase_views,
    )

    app.register_blueprint(main_views.bp)
    app.register_blueprint(homepage_views.bp)
    app.register_blueprint(schedule_views.bp)
    app.register_blueprint(question_views.bp)
    app.register_blueprint(answer_views.bp)
    app.register_blueprint(auth_views.bp)
    app.register_blueprint(equipment_views.bp)
    app.register_blueprint(person_views.bp)
    app.register_blueprint(license_views.bp)
    app.register_blueprint(ip_views.bp)
    app.register_blueprint(admin_views.bp)
    app.register_blueprint(purchase_views.bp)

    # 필터 설정
    from .filter import formate_datetime, formate_datetime_notime, is_within_30_days
    app.jinja_env.filters["datetime"] = formate_datetime
    app.jinja_env.filters["datetime_notime"] = formate_datetime_notime
    app.jinja_env.filters['is_within_30_days'] = is_within_30_days

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=8000)
