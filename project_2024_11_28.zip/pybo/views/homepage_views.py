from flask import Blueprint, render_template, send_file
from pybo.views.main_views import permission_required
from pybo.models import Equipment, EquipmentList, LowerTab, License, Headquarter, SSD, BuyProduct
from datetime import datetime, timedelta
import csv
import io

bp = Blueprint("homepage", __name__, url_prefix="/homepage")


@bp.route("/list/")
@permission_required(['admin'])
def _list():
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    headquarter_list = Headquarter.query.order_by(Headquarter.name.asc())
    equipment_list = EquipmentList.query.order_by(EquipmentList.name.asc())
    reference_date = datetime.now()

    # 장비 관련 계산
    equipment_use_count = {}
    for equipment in equipment_list:
        total_count = Equipment.query.filter(Equipment.kind == equipment.name).count()
        use_count = Equipment.query.filter(Equipment.kind == equipment.name, Equipment.person != "None").count()
        equipment_use_count[equipment.name] = {"total_count": total_count, "use_count": use_count}

        for headquarter in headquarter_list:
            headquarter_use_count = Equipment.query.filter(Equipment.kind == equipment.name,
                                                           Equipment.headquarter == headquarter.name).count()
            equipment_use_count[equipment.name][headquarter.name] = headquarter_use_count

    # 라이센스 관련 계산
    license_use_count = {}
    for lower_tab in lower_tab_list:
        legal_use = License.query.filter(License.sub_kind == lower_tab.name, License.person != "None",
                                         License.renew != "비정품").count()
        illegal_count = License.query.filter(License.sub_kind == lower_tab.name, License.renew == "비정품").count()
        license_use_count[lower_tab.name] = {"legal_use": legal_use}
        license_use_count[lower_tab.name]["illegal_count"] = illegal_count

        buy_product = BuyProduct.query.filter(BuyProduct.product_name == lower_tab.name).all()

        license_use_count[lower_tab.name]["buy_count"] = 0
        for product in buy_product:
            if product.renew == "라이센스(갱신)" and product.expire_date >= reference_date:
                license_use_count[lower_tab.name]["buy_count"] += product.amount
            elif product.renew == "라이센스(영구)":
                license_use_count[lower_tab.name]["buy_count"] += product.amount

        for headquarter in headquarter_list:
            headquarter_legal_count = License.query.filter(License.sub_kind == lower_tab.name,
                                                           License.headquarter == headquarter.name,
                                                           License.person != "None",
                                                           License.renew != "비정품").count()
            headquarter_illegal_count = License.query.filter(License.sub_kind == lower_tab.name,
                                                             License.headquarter == headquarter.name,
                                                             License.renew == "비정품").count()
            license_use_count[lower_tab.name][headquarter.name + "_legal"] = headquarter_legal_count
            license_use_count[lower_tab.name][headquarter.name + "_illegal"] = headquarter_illegal_count

    buy_products = BuyProduct.query.order_by(BuyProduct.product_name.asc())
    expire_list = []
    for product in buy_products:
        if product.expire_date and product.expire_date - timedelta(
                days=30) <= reference_date and product.expire_date >= reference_date:
            expire_list.append({"종류": product.product_name, "수량": product.amount, "만료일": product.expire_date})

    return render_template("homepage/homepage_list.html", lower_tab_list=lower_tab_list,
                           headquarter_list=headquarter_list, license_use_count=license_use_count,
                           equipment_list=equipment_list, equipment_use_count=equipment_use_count,
                           expire_list=expire_list)


@bp.route("/download_database/")
@permission_required(['admin'])
def download_database():
    equipment_list = Equipment.query.order_by(Equipment.kind.asc())
    license_list = License.query.order_by(License.sub_kind.asc())
    ssd_list = SSD.query.order_by(SSD.id.asc())

    equipment_data = []
    for equipment in equipment_list:

        ssds = []
        ssds_price = 0
        for s in ssd_list:
            if s.equipment_id == equipment.id:
                ssds.append(s.name)
                ssds_price += s.price

        ssds = ",".join(ssds)

        equipment_data.append(
            {"장비종류": equipment.kind, "장비번호": equipment.serial, "사용자": equipment.person, "아이디": equipment.nickname,
             "본부": equipment.headquarter, "부서": equipment.department, "IP 주소": equipment.ip_add,
             "구매일": equipment.buy_date, "CPU": equipment.cpu, "CPU_금액": equipment.cpu_price,
             "메인보드": equipment.mainboard, "메인보드_금액": equipment.mainboard_price, "메모리": equipment.memory,
             "단가": equipment.memory_price,
             "개수": equipment.memory_count,
             "메모리_금액": equipment.memory_sum, "그래픽카드": equipment.graphiccard, "그래픽카드_금액": equipment.graphiccard_price,
             "HARD/SSD": ssds, "HARD/SSD_금액": ssds_price, "부분합계(자동)": equipment.subtotal,
             "부분합계(입력)": equipment.subtotal2, "VAT": equipment.vat,
             "총금액": equipment.total, "S/N, Mac 주소": equipment.equip_num, "비고": equipment.note})

    license_data = []
    for license in license_list:
        license_data.append(
            {"라이센스 종류": license.sub_kind, "라이센스 번호": license.product_name, "사용자": license.person,
             "아이디": license.nickname, "본부": license.headquarter, "부서": license.department,
             "분류": license.renew})

    # CSV 파일을 메모리에 생성
    output = io.StringIO()
    writer = csv.writer(output)

    # 장비 데이터 작성
    writer.writerow(["장비 리스트"])
    writer.writerow(["장비종류", "장비번호", "사용자", "아이디", "본부", "부서", "IP 주소", "구매일", "CPU",
                     "CPU_금액", "메인보드", "메인보드_금액", "메모리", "단가", "개수", "메모리_금액", "그래픽카드", "그래픽카드_금액",
                     "HARD/SSD", "HARD/SSD_금액", "부분합계(자동)", "부분합계(입력)", "VAT", "총금액", "S/N, Mac 주소", "비고"])

    for row in equipment_data:
        writer.writerow(
            [row['장비종류'], row['장비번호'], row['사용자'], row['아이디'], row['본부'], row['부서'], row['IP 주소'], row['구매일'],
             row['CPU'], row['CPU_금액'], row['메인보드'], row['메인보드_금액'], row['메모리'], row['단가'], row['개수'], row['메모리_금액'],
             row['그래픽카드'], row['그래픽카드_금액'], row['HARD/SSD'], row['HARD/SSD_금액'], row['부분합계(자동)'], row['부분합계(입력)'],
             row['VAT'], row['총금액'],
             row['S/N, Mac 주소'],
             row['비고']])

    writer.writerow([])  # 빈 줄 추가
    writer.writerow([])  # 빈 줄 추가

    # 라이센스 데이터 작성
    writer.writerow(["라이센스 리스트"])
    writer.writerow(["라이센스 종류", "라이센스 번호", "사용자", "아이디", "본부", "부서", "분류"])

    for row in license_data:
        writer.writerow(
            [row['라이센스 종류'], row['라이센스 번호'], row['사용자'], row['아이디'], row['본부'], row['부서'],
             row['분류']])

    output.seek(0)

    # 파일 이름 설정
    filename = f"Backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

    return send_file(io.BytesIO(output.getvalue().encode('utf-8-sig')),
                     mimetype='text/csv',
                     as_attachment=True,
                     download_name=filename)
