'use strict';

require('../css/timepicker.css');

module.exports = require('./timepicker');
