from flask import Blueprint, render_template, request, redirect, url_for
from pybo import db
from pybo.forms import IpForm, IpSectionForm
from pybo.models import Ip, Equipment, IpSectionList
from pybo.views.main_views import permission_required

bp = Blueprint("ip", __name__, url_prefix="/ip")


@bp.route("/list/")
@permission_required(['admin'])
def _list():
    item_list = Ip.query.order_by(Ip.ip_add.asc())
    ip_total = Ip.query.count()
    ip_not_enrolled = Ip.query.filter(Ip.person.is_(None)).count()
    ip_enrolled = Ip.query.filter(Ip.person.isnot(None)).count()
    section_list = IpSectionList.query.order_by(IpSectionList.section.asc())
    detail_list = {part.section: Ip.query.filter_by(section=part.section).order_by(Ip.ip_add.asc()).all()
                   for part in section_list}

    return render_template("ip/ip_list.html", item_list=item_list, ip_total=ip_total, ip_enrolled=ip_enrolled,
                           section_list=section_list, detail_list=detail_list)


@bp.route("/enroll/")
@permission_required(['admin'])
def enroll():
    form = IpForm()
    ip_list = Ip.query.order_by(Ip.person.asc())
    section_list = IpSectionList.query.order_by(IpSectionList.section.asc())

    return render_template("ip/ip_enroll.html", ip_list=ip_list, section_list=section_list, form=form)


@bp.route("/enroll_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def enroll_complete():
    form = IpForm()
    ip_list = Ip.query.order_by(Ip.person.asc())
    item = Ip.query.filter_by(ip_add=form.ip_add.data.strip()).first()

    if request.method == "POST" and form.validate_on_submit():
        if not item:
            ip = Ip(
                ip_add=form.ip_add.data.strip(),
                section=form.section.data,
                person=None,
                nickname=None,
                headquarter=None,
                department=None,
                serial=None,
                note=None,
            )
            db.session.add(ip)
            db.session.commit()

            return redirect(url_for("ip._list"))
        else:
            return "이미 등록된 IP 주소입니다", 404
    return render_template("ip/ip_enroll.html", form=form, ip_list=ip_list)


@bp.route("/add/")
@permission_required(['admin'])
def add():
    form = IpSectionForm()

    if request.method == "POST" and form.validate_on_submit():
        return redirect(url_for("ip._list"))
    return render_template("ip/ip_add.html", form=form)


@bp.route("/add_complete/", methods=["GET", "POST"])
@permission_required(['admin'])
def add_complete():
    form = IpSectionForm()
    item_list = Ip.query.order_by(Ip.ip_add.asc())
    ip_total = Ip.query.count()
    ip_not_enrolled = Ip.query.filter(Ip.person.is_(None)).count()
    section = form.name.data
    action = request.form['action']
    if request.method == "POST" and form.validate_on_submit():
        if action == "추가":
            if IpSectionList.query.filter_by(section=section).first():
                return "구간이 이미 존재합니다.", 404
            ip_section = IpSectionList(section=section)
            db.session.add(ip_section)
            db.session.commit()
            return redirect(url_for("ip._list"))
        elif action == "삭제":
            ip_section = IpSectionList.query.filter_by(section=section).first()
            ip_list = Ip.query.filter_by(section=section).all()
            if ip_section:
                db.session.delete(ip_section)
                for ip in ip_list:  # 리스트의 각 객체를 삭제
                    equipment = Equipment.query.filter_by(ip_add=ip.ip_add).first()
                    if equipment:
                        equipment.ip_add = "None"
                    db.session.delete(ip)

                db.session.commit()
                return redirect(url_for("ip._list"))
            else:
                # 삭제할 항목이 없는 경우 처리
                return "삭제할 항목이 없습니다.", 404
    return render_template("ip/ip_list.html", item_list=item_list, ip_total=ip_total, ip_not_enrolled=ip_not_enrolled)


@bp.route("/delete/<int:product_id>/")
@permission_required(['admin'])
def delete(product_id):
    item = Ip.query.filter_by(id=product_id).first()
    equipment = Equipment.query.filter_by(ip_add=item.ip_add).first()
    if equipment:
        equipment.ip_add = "None"
    db.session.delete(item)
    db.session.commit()
    return render_template("ip/ip_delete.html", item=item)
