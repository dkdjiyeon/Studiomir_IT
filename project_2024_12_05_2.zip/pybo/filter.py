def formate_datetime(value, fmt="%Y년 %m월 %d일 %p %I:%M"):
    return value.strftime(fmt)


def formate_datetime_notime(value, fmt="%Y-%m-%d"):
    if value is None:
        return ""
    return value.strftime(fmt)


def formate_currency(value):
    if value is None:
        return ""
    return f"{int(value):,.0f}"


def is_within_30_days(expire_date, reference_date):
    # expire_date가 None일 경우 False 반환
    if expire_date is None:
        return False
    return (expire_date - reference_date).days < 30
