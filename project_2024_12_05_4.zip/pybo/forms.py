from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, PasswordField, DateField, SubmitField, IntegerField, SelectField
from wtforms.validators import DataRequired, Length, EqualTo, Regexp, Optional, NumberRange


# form이란 입력 칸의 내용이 올바르게 입력됐는지 체크하는 것
class QuestionForm(FlaskForm):
    subject = StringField("제목", validators=[DataRequired("제목은 필수입력 항목입니다.")])
    content = TextAreaField("내용", validators=[DataRequired("내용은 필수입력 항목입니다.")])


class AnswerForm(FlaskForm):
    content = TextAreaField("내용", validators=[DataRequired("내용은 필수입력 항목입니다.")])


class UserCreateForm(FlaskForm):
    userid = StringField("아이디", validators=[DataRequired(), Length(min=1, max=25)])
    username = StringField("사용자이름", validators=[DataRequired(), Length(min=3, max=25)])
    password1 = PasswordField(
        "비밀번호",
        validators=[
            DataRequired(),
            Length(min=8, message="비밀번호는 최소 8자 이상이어야 합니다."),
            Regexp(r'^(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*])',
                   message="비밀번호는 소문자, 숫자, 특수문자를 포함해야 합니다."
                   ),
            EqualTo("password2", message="비밀번호가 일치하지 않습니다.")
        ]
    )

    password2 = PasswordField("비밀번호확인", validators=[DataRequired()])
    level = StringField("레벨", validators=[DataRequired(), Length(min=1, max=25)])


class PasswordForm(FlaskForm):
    password1 = PasswordField(
        '새 비밀번호',
        validators=[
            Optional(),  # 선택적 입력 허용
            Length(min=8, message="비밀번호는 최소 8자 이상이어야 합니다."),
            Regexp(
                r'^(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*])',
                message="비밀번호는 소문자, 숫자, 특수문자를 포함해야 합니다."
            )
        ]
    )
    password2 = PasswordField(
        '비밀번호 확인',
        validators=[
            Optional(),  # 선택적 입력 허용
            EqualTo('password1', message="비밀번호가 일치하지 않습니다.")
        ]
    )
    submit = SubmitField('정보 변경')


class UserLoginForm(FlaskForm):
    userid = StringField("아이디", validators=[DataRequired(), Length(min=1, max=25)])
    password = PasswordField("비밀번호", validators=[DataRequired()])


class SearchForm(FlaskForm):
    name = StringField("이름", validators=[DataRequired("이름는 필수입력 항목입니다.")])


class ProductForm(FlaskForm):
    kind = StringField("종류")
    serial = StringField("장비번호", validators=[DataRequired("장비번호는 필수입력 항목입니다.")])
    person = StringField("사용자")
    nickname = StringField("아이디")
    headquarter = StringField("본부")
    department = StringField("부서")
    ip_add = StringField("아이피")
    buy_date = DateField("구매일", format="%Y-%m-%d", validators=[DataRequired("구매일은 필수입력 항목입니다.")])
    cpu = StringField("프로세서")
    cpu_price = IntegerField("cpu 금액", validators=[NumberRange(min=0)])
    mainboard = StringField("메인보드")
    mainboard_price = IntegerField("메인보드 금액", validators=[NumberRange(min=0)])
    graphiccard = StringField("그래픽카드")
    graphiccard_price = IntegerField("그래픽카드 금액", validators=[NumberRange(min=0)])
    memory = StringField("메모리")
    memory_price = IntegerField("메모리 단가", validators=[NumberRange(min=0)])
    memory_count = IntegerField("메모리 수량", validators=[NumberRange(min=0)])
    memory_sum = IntegerField("메모리 합계", validators=[NumberRange(min=0)])
    equip_num = StringField("시리얼/Mac 주소")
    vat = IntegerField("부가세", validators=[NumberRange(min=0)])
    subtotal = IntegerField("부분합계", validators=[NumberRange(min=0)])
    subtotal2 = IntegerField("부분합계2", validators=[NumberRange(min=0)])
    total = IntegerField("총합계", validators=[NumberRange(min=0)])
    note = StringField("비고")


class BuyForm(FlaskForm):
    product_name = StringField("품명")
    renew = StringField("품목")
    serial = StringField("문서번호")
    buy_date = DateField("구매일", format="%Y-%m-%d")
    expire_date = DateField("만료일", validators=[Optional()])
    amount = IntegerField("수량", validators=[NumberRange(min=0)])
    price = IntegerField("금액", validators=[NumberRange(min=0)])
    vat = IntegerField("VAT", validators=[NumberRange(min=0)])
    total = IntegerField("총금액", validators=[NumberRange(min=0)])
    note = StringField("비고")


class RenewForm(FlaskForm):
    renew = StringField("종류", validators=[DataRequired("필수입력 항목입니다.")])


class ItemForm(FlaskForm):
    name = StringField("종류", validators=[DataRequired("필수입력 항목입니다.")])


class RenewChangeForm(FlaskForm):
    renew_change = SelectField('갱신여부', choices=[('갱신', '갱신'), ('영구', '영구'), ('비정품', '비정품')],
                               validators=[DataRequired()])


class TabForm(FlaskForm):
    upper_tab = StringField("상위탭명", validators=[DataRequired("탭명은 필수입력 항목입니다.")])
    lower_tab = StringField("하위탭명", validators=[DataRequired("탭명은 필수입력 항목입니다.")])


class TabListForm(FlaskForm):
    upper_tab = StringField("상위탭명")
    lower_tab = StringField("하위탭명")


class LicenseForm(FlaskForm):
    kind = StringField("상위탭종류", validators=[DataRequired("상위탭은 필수입력 항목입니다.")])
    sub_kind = StringField("하위탭종류", validators=[DataRequired("하위탭은 필수입력 항목입니다.")])
    product_name = StringField("라이센스 번호", validators=[Optional()])
    person = StringField("사용자")
    nickname = StringField("아이디")
    headquarter = StringField("본부")
    department = StringField("부서")
    note = StringField("비고")
    renew = StringField("갱신여부")


class PersonForm(FlaskForm):
    name = StringField("사용자", validators=[DataRequired("사용자는 필수입력 항목입니다.")])
    nickname = StringField("아이디", validators=[DataRequired("아이디는 필수입력 항목입니다.")])
    headquarter = StringField("본부", validators=[DataRequired("본부는 필수입력 항목입니다.")])
    department = StringField("부서", validators=[DataRequired("부서는 필수입력 항목입니다.")])


class DepartmentForm(FlaskForm):
    name = StringField("부서명", validators=[DataRequired("부서명은 필수입력 항목입니다.")])


class HeadquarterForm(FlaskForm):
    name = StringField("본부명", validators=[DataRequired("본부명은 필수입력 항목입니다.")])


class IpForm(FlaskForm):
    ip_add = StringField("아이피주소", validators=[DataRequired("아이피주소는 필수입력 항목입니다.")])
    section = StringField("구간", validators=[DataRequired("구간은 필수입력 항목입니다.")])


class IpSectionForm(FlaskForm):
    name = StringField("구간 설정", validators=[DataRequired(message="구간은 필수 입력 항목입니다.")])
