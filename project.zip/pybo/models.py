from pybo import db
from enum import Enum
from sqlalchemy import Enum as SQLAEnum

# 데이터 베이스에 저장될 항목들


question_voter = db.Table("question_voter",  # 첫 번째 인자로 테이블 이름을 전달
                          db.Column("user_id", db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"),
                                    primary_key=True, ),
                          db.Column("question_id", db.Integer, db.ForeignKey("question.id", ondelete="CASCADE"),
                                    primary_key=True, ), )

answer_voter = db.Table("answer_voter",
                        db.Column("user_id", db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"),
                                  primary_key=True, ),
                        db.Column("answer_id", db.Integer, db.ForeignKey("answer.id", ondelete="CASCADE"),
                                  primary_key=True, ), )


class UserLevelEnum(Enum):
    basic = "basic"
    read = "read"
    admin = "admin"


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    userid = db.Column(db.String(150), nullable=False, unique=True)
    password = db.Column(db.String(200), nullable=False)
    username = db.Column(db.String(150), nullable=False)
    level = db.Column(SQLAEnum(UserLevelEnum), default=UserLevelEnum.basic)


class Worker(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    nickname = db.Column(db.String(50), nullable=False, unique=True)
    department = db.Column(db.String(50), nullable=False)
    headquarter = db.Column(db.String(50), nullable=False)


class Department(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)


class Headquarter(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)


class Question(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    subject = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text(), nullable=False)
    image_path = db.Column(db.String(300))
    create_date = db.Column(db.DateTime(), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False)
    user = db.relationship("User", backref=db.backref("question_set"))
    modify_date = db.Column(db.DateTime(), nullable=True)
    voter = db.relationship("User", secondary=question_voter, backref=db.backref("question_voter_set"))


class Answer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey("question.id", ondelete="CASCADE"))
    question = db.relationship("Question", backref=db.backref("answer_set"))
    content = db.Column(db.Text(), nullable=False)
    create_date = db.Column(db.DateTime(), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False)
    user = db.relationship("User", backref=db.backref("answer_set"))
    modify_date = db.Column(db.DateTime(), nullable=True)
    voter = db.relationship("User", secondary=answer_voter, backref=db.backref("answer_voter_set"))


class Equipment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    kind = db.Column(db.String(50), nullable=False)
    serial = db.Column(db.String(50), nullable=False, unique=True)
    person = db.Column(db.String(50))
    nickname = db.Column(db.String(50))
    department = db.Column(db.String(50))
    headquarter = db.Column(db.String(50))
    ip_add = db.Column(db.String(50))
    buy_date = db.Column(db.DateTime(), nullable=False)
    cpu = db.Column(db.String(50))
    mainboard = db.Column(db.String(50))
    memory = db.Column(db.String(50))
    graphiccard = db.Column(db.String(50))
    ssd = db.Column(db.String(50))
    hard = db.Column(db.String(50))
    price = db.Column(db.String(50))
    cpu_price = db.Column(db.String(50))
    mainboard_price = db.Column(db.String(50))
    memory_price = db.Column(db.String(50))
    graphiccard_price = db.Column(db.String(50))
    ssd_price = db.Column(db.String(50))
    hard_price = db.Column(db.String(50))
    sum_price = db.Column(db.String(50))
    equip_num = db.Column(db.String(50))
    note = db.Column(db.String(200))
    qr_code_path = db.Column(db.String(200))


class Ip(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ip_add = db.Column(db.String(50), nullable=False, unique=True)
    person = db.Column(db.String(50))
    nickname = db.Column(db.String(50))
    headquarter = db.Column(db.String(50))
    department = db.Column(db.String(50))
    serial = db.Column(db.String(50))
    note = db.Column(db.String(200))


class IpHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ip_add = db.Column(db.String(50))
    person = db.Column(db.String(50))
    nickname = db.Column(db.String(50))
    headquarter = db.Column(db.String(50))
    department = db.Column(db.String(50))
    serial = db.Column(db.String(50))
    note = db.Column(db.String(200))
    modify_date = db.Column(db.DateTime(), nullable=True)


class EquipmentHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    kind = db.Column(db.String(50))
    serial = db.Column(db.String(50))
    person = db.Column(db.String(50))
    nickname = db.Column(db.String(50))
    department = db.Column(db.String(50))
    headquarter = db.Column(db.String(50))
    ip_add = db.Column(db.String(50))
    buy_date = db.Column(db.DateTime())
    cpu = db.Column(db.String(50))
    mainboard = db.Column(db.String(50))
    memory = db.Column(db.String(50))
    graphiccard = db.Column(db.String(50))
    ssd = db.Column(db.String(50))
    hard = db.Column(db.String(50))
    price = db.Column(db.Integer)
    cpu_price = db.Column(db.String(50))
    mainboard_price = db.Column(db.String(50))
    memory_price = db.Column(db.String(50))
    graphiccard_price = db.Column(db.String(50))
    ssd_price = db.Column(db.String(50))
    hard_price = db.Column(db.String(50))
    sum_price = db.Column(db.String(50))
    note = db.Column(db.String(200))
    equip_num = db.Column(db.String(50))
    equipment_id = db.Column(db.Integer, db.ForeignKey("equipment.id", ondelete="CASCADE"))
    modify_date = db.Column(db.DateTime(), nullable=True)


class EquipmentList(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)


class Schedule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=True)


class License(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String(50), nullable=False, unique=True)
    kind = db.Column(db.String(50), nullable=False)
    sub_kind = db.Column(db.String(50), nullable=False)
    person = db.Column(db.String(50))
    nickname = db.Column(db.String(50))
    headquarter = db.Column(db.String(50))
    department = db.Column(db.String(50))
    price = db.Column(db.String(50))
    buy_date = db.Column(db.DateTime(), nullable=False)
    note = db.Column(db.String(50))
    renew = db.Column(db.String(50))
    expire_date = db.Column(db.DateTime())
    one_month_before = db.Column(db.DateTime())


class LicenseHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String(50))
    kind = db.Column(db.String(50))
    sub_kind = db.Column(db.String(50))
    person = db.Column(db.String(50))
    nickname = db.Column(db.String(50))
    headquarter = db.Column(db.String(50))
    department = db.Column(db.String(50))
    price = db.Column(db.String(50))
    buy_date = db.Column(db.DateTime())
    note = db.Column(db.String(50))
    renew = db.Column(db.String(50))
    expire_date = db.Column(db.DateTime())
    license_id = db.Column(db.Integer, db.ForeignKey("license.id", ondelete="CASCADE"))
    modify_date = db.Column(db.DateTime(), nullable=True)


class UpperTab(db.Model):
    __tablename__ = 'upper_tabs'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False, unique=True)
    lower_tabs = db.relationship('LowerTab', backref='upper_tab', lazy=True, cascade="all, delete-orphan")


class LowerTab(db.Model):
    __tablename__ = 'lower_tabs'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False, unique=True)
    upper_tab_id = db.Column(db.Integer, db.ForeignKey('upper_tabs.id'), nullable=False)
