import os
from datetime import datetime

from flask import Blueprint, render_template, request, url_for, g, flash, current_app
from werkzeug.utils import redirect
from werkzeug.utils import secure_filename

from pybo import db
from pybo.forms import QuestionForm, AnswerForm
from pybo.models import Question, Answer, User, QuestionVoter
from pybo.views.main_views import permission_required

bp = Blueprint("question", __name__, url_prefix="/question")


@bp.route("/list/")
@permission_required(['admin'])
def _list():
    page = request.args.get("page", type=int, default=1)
    kw = request.args.get("kw", type=str, default="")
    question_list = Question.query.order_by(Question.create_date.desc())
    if kw:
        search = "%%{}%%".format(kw)
        sub_query = (
            db.session.query(Answer.question_id, Answer.content, User.username)
            .join(User, Answer.user_id == User.id)
            .subquery()
        )
        question_list = (
            question_list.join(User)
            .outerjoin(sub_query, sub_query.c.question_id == Question.id)
            .filter(
                Question.subject.ilike(search)  # 질문제목
                | Question.content.ilike(search)  # 질문내용
                | User.username.ilike(search)  # 질문작성자
                | sub_query.c.content.ilike(search)  # 답변내용
                | sub_query.c.username.ilike(search)  # 답변작성자
            )
            .distinct()
        )
    question_list = question_list.paginate(page=page, per_page=10)
    return render_template("question/question_list.html", question_list=question_list, page=page, kw=kw)


@bp.route("/detail/<int:question_id>/")
@permission_required(['admin'])
def detail(question_id):
    form = AnswerForm()
    question = Question.query.get_or_404(question_id)
    # 파일 경로에서 파일명만 추출
    file_path = os.path.basename(question.file_path) if question.file_path else None

    return render_template("question/question_detail.html", question=question, form=form, file_path=file_path)


ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'xlsm', 'csv', 'hwp', 'hwpx'}


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def is_image(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'png', 'jpg', 'jpeg', 'gif'}


@bp.route("/create/", methods=["GET", "POST"])
@permission_required(['admin'])
def create():
    form = QuestionForm()

    if request.method == "POST" and form.validate_on_submit():
        question = Question(
            subject=form.subject.data,
            content=form.content.data,
            create_date=datetime.now(),
            user=g.user,
        )

        # 파일 처리
        file = request.files.get('file')
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            # 파일 경로를 저장 (파일 경로와 유형에 따라 분리 가능)
            # question.file_path = 'uploads/' + filename
            question.file_path = file_path

        # 질문 데이터베이스에 추가
        db.session.add(question)
        db.session.commit()
        return redirect(url_for("question._list"))

    return render_template("question/question_form.html", form=form)


@bp.route("/revise/<int:question_id>", methods=["GET", "POST"])
@permission_required(['admin'])
def revise(question_id):
    question = Question.query.get_or_404(question_id)
    form = QuestionForm(obj=question)
    # 파일 경로에서 파일명만 추출
    file_path = os.path.basename(question.file_path) if question.file_path else None

    return render_template("question/question_revise.html", form=form, question=question, file_path=file_path)


@bp.route("/modify/<int:question_id>", methods=["GET", "POST"])
@permission_required(['admin'])
def modify(question_id):
    question = Question.query.get_or_404(question_id)

    if g.user != question.user:
        flash("수정 권한이 없습니다")
        return redirect(url_for("question.detail", question_id=question_id))

    form = QuestionForm(obj=question)
    if request.method == "POST" and form.validate_on_submit():
        form.populate_obj(question)
        question.modify_date = datetime.now()

        # 이미지 파일 처리
        file = request.files.get('file')
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)

            # 기존 이미지 삭제 후 새 이미지 저장
            if question.file_path:
                old_file_path = os.path.join(current_app.root_path, question.file_path)
                if os.path.exists(old_file_path):
                    os.remove(old_file_path)

            file.save(file_path)
            question.file_path = 'uploads/' + filename

        db.session.commit()
        return redirect(url_for("question.detail", question_id=question_id))

    return render_template("question/question_form.html", form=form)


@bp.route('/delete/<int:question_id>')
@permission_required(['admin'])
def delete(question_id):
    _question = Question.query.get_or_404(question_id)
    db.session.delete(_question)
    db.session.commit()
    return redirect(url_for('question._list'))


@bp.route("/vote/<int:question_id>/")
@permission_required(['admin'])
def vote(question_id):
    question_check = QuestionVoter.query.filter(QuestionVoter.id == question_id).first()
    _question = Question.query.get_or_404(question_id)
    if question_check:
        db.session.delete(question_check)  # question_check 삭제
        db.session.commit()
        return redirect(url_for("question.detail", question_id=question_id))

    else:
        _question.voter.append(g.user)
        db.session.commit()
        return redirect(url_for("question.detail", question_id=question_id))
