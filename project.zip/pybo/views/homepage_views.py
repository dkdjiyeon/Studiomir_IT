from flask import Blueprint, render_template
from pybo.views.main_views import permission_required
from pybo.models import Equipment, EquipmentList, LowerTab, License, Headquarter
from datetime import datetime

bp = Blueprint("homepage", __name__, url_prefix="/homepage")


@bp.route("/list/")
@permission_required(['admin'])
def _list():
    lower_tab_list = LowerTab.query.order_by(LowerTab.name.asc())
    headquarter_list = Headquarter.query.order_by(Headquarter.name.asc())
    equipment_list = EquipmentList.query.order_by(EquipmentList.name.asc())
    license_list = License.query.order_by(License.sub_kind.asc())
    reference_date = datetime.now()

    # 장비 관련 계산
    equipment_use_count = {}
    for equipment in equipment_list:
        use_count = Equipment.query.filter(Equipment.kind == equipment.name, Equipment.person != "None").count()
        not_use_count = Equipment.query.filter(Equipment.kind == equipment.name, Equipment.person == "None").count()
        equipment_use_count[equipment.name] = {"use_count": use_count, "not_use_count": not_use_count}

        for headquarter in headquarter_list:
            headquarter_use_count = Equipment.query.filter(Equipment.kind == equipment.name,
                                                           Equipment.headquarter == headquarter.name).count()
            equipment_use_count[equipment.name][headquarter.name] = headquarter_use_count

    # 라이센스 관련 계산
    license_use_count = {}
    for lower_tab in lower_tab_list:
        legal_count = License.query.filter(License.sub_kind == lower_tab.name, License.renew != "비정품").count()
        legal_use = License.query.filter(License.sub_kind == lower_tab.name, License.person != "None",
                                         License.renew != "비정품").count()
        legal_not_use = License.query.filter(License.sub_kind == lower_tab.name, License.person == "None",
                                             License.renew != "비정품").count()
        illegal_count = License.query.filter(License.sub_kind == lower_tab.name, License.renew == "비정품").count()
        expire_check = License.query.filter(License.sub_kind == lower_tab.name,
                                            License.one_month_before < reference_date).count()
        license_use_count[lower_tab.name] = {"legal_count": legal_count}
        license_use_count[lower_tab.name]["legal_use"] = legal_use
        license_use_count[lower_tab.name]["legal_not_use"] = legal_not_use
        license_use_count[lower_tab.name]["illegal_count"] = illegal_count
        license_use_count[lower_tab.name]["expire_check"] = expire_check

        for headquarter in headquarter_list:
            headquarter_legal_count = License.query.filter(License.sub_kind == lower_tab.name,
                                                           License.headquarter == headquarter.name,
                                                           License.renew != "비정품").count()
            headquarter_illegal_count = License.query.filter(License.sub_kind == lower_tab.name,
                                                             License.headquarter == headquarter.name,
                                                             License.renew == "비정품").count()
            license_use_count[lower_tab.name][headquarter.name + "_legal"] = headquarter_legal_count
            license_use_count[lower_tab.name][headquarter.name + "_illegal"] = headquarter_illegal_count

    # 만료예정 관련 계산
    expire_list = []
    for license in license_list:
        if not license.one_month_before is None:
            if license.one_month_before < reference_date:
                expire_list.append(license)

    return render_template("homepage/homepage_list.html", lower_tab_list=lower_tab_list,
                           headquarter_list=headquarter_list, license_use_count=license_use_count,
                           equipment_list=equipment_list, equipment_use_count=equipment_use_count,
                           expire_list=expire_list)
